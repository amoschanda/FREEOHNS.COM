import os
import subprocess
import sys
import shutil

def run_command(command, cwd=None):
    print(f"Executing: {command}")
    process = subprocess.Popen(command, shell=True, cwd=cwd)
    process.wait()
    if process.returncode != 0:
        print(f"Command failed with return code {process.returncode}")
        return False
    return True

def setup_environment():
    print("--- Setting up environment ---")
    
    # Install Python dependencies
    print("Installing backend dependencies...")
    run_command("pip install fastapi uvicorn pydantic[email] pyjwt python-dotenv")
    
    # Install Frontend dependencies
    if os.path.exists("frontend"):
        print("Installing frontend dependencies...")
        run_command("npm install", cwd="frontend")
    else:
        print("Error: frontend directory not found")

def build_android():
    print("--- Preparing Android Build ---")
    if not os.path.exists("frontend"):
        print("Error: frontend directory not found")
        return

    # Check for Expo CLI and run prebuild to generate native android folder
    print("Running Expo prebuild...")
    run_command("npx expo prebuild", cwd="frontend")
    
    print("Building Android APK (debug mode)...")
    # This requires Android SDK and Gradle to be installed on the system
    android_dir = os.path.join("frontend", "android")
    if os.path.exists(android_dir):
        # Make gradlew executable
        run_command("chmod +x gradlew", cwd=android_dir)
        # Build APK
        run_command("./gradlew assembleDebug", cwd=android_dir)
        # Build AAB
        run_command("./gradlew bundleRelease", cwd=android_dir)
    else:
        print("Error: Android directory not found after prebuild")

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 dependency.py [setup|build|all]")
        return

    action = sys.argv[1]
    
    if action == "setup":
        setup_environment()
    elif action == "build":
        build_android()
    elif action == "all":
        setup_environment()
        build_android()
    else:
        print(f"Unknown action: {action}")

if __name__ == "__main__":
    main()
