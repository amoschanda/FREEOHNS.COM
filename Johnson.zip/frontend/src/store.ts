import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const API_URL = process.env.EXPO_PUBLIC_BACKEND_URL || '';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  created_at: string;
}

export interface Ride {
  id: string;
  user_id: string;
  user_name: string;
  destination_label: string;
  destination_x: number;
  destination_y: number;
  fare: number;
  pickup_location: string;
  status: string;
  driver_name?: string;
  driver_eta?: number;
  created_at: string;
  local_id?: string;
  synced?: boolean;
}

export interface Message {
  id: string;
  ride_id: string;
  sender_id: string;
  text: string;
  created_at: string;
}

export interface Destination {
  label: string;
  fare: number;
  xPercent: number;
  yPercent: number;
}

interface AppState {
  user: User | null;
  token: string | null;
  selectedRole: string | null;
  isLoading: boolean;
  isOnline: boolean;
  rides: Ride[];
  pendingRides: Ride[];
  currentDestination: Destination | null;
  activeRide: Ride | null;
  
  setSelectedRole: (role: string | null) => void;
  setDestination: (dest: Destination | null) => void;
  setActiveRide: (ride: Ride | null) => void;
  
  login: (email: string, password: string, role: string) => Promise<boolean>;
  register: (name: string, email: string, password: string, phone: string, role: string) => Promise<boolean>;
  logout: () => Promise<void>;
  loadStoredAuth: () => Promise<void>;
  
  requestRide: () => Promise<Ride | null>;
  loadRides: () => Promise<void>;
  cancelRide: (rideId: string) => Promise<void>;
  
  syncData: () => Promise<void>;
  setOnlineStatus: (status: boolean) => void;

  loadMessages: (rideId: string) => Promise<Message[]>;
  sendMessage: (rideId: string, text: string) => Promise<void>;
}

export const useStore = create<AppState>((set, get) => ({
  user: null,
  token: null,
  selectedRole: null,
  isLoading: false,
  isOnline: true,
  rides: [],
  pendingRides: [],
  currentDestination: null,
  activeRide: null,

  setSelectedRole: (role) => set({ selectedRole: role }),
  setDestination: (dest) => set({ currentDestination: dest }),
  setActiveRide: (ride) => set({ activeRide: ride }),
  setOnlineStatus: (status) => set({ isOnline: status }),

  loadStoredAuth: async () => {
    try {
      const storedUser = await AsyncStorage.getItem('user');
      const storedToken = await AsyncStorage.getItem('token');
      const storedRides = await AsyncStorage.getItem('rides');
      const storedPending = await AsyncStorage.getItem('pendingRides');
      
      if (storedUser && storedToken) {
        set({
          user: JSON.parse(storedUser),
          token: storedToken,
          rides: storedRides ? JSON.parse(storedRides) : [],
          pendingRides: storedPending ? JSON.parse(storedPending) : []
        });
      }
    } catch (error) {
      console.error('Error loading stored auth:', error);
    }
  },

  login: async (email, password, role) => {
    set({ isLoading: true });
    const { isOnline } = get();
    
    if (!isOnline) {
      const storedUsers = await AsyncStorage.getItem('offlineUsers');
      if (storedUsers) {
        const users = JSON.parse(storedUsers);
        const user = users.find((u: any) => u.email === email.toLowerCase() && u.password === password);
        if (user) {
          const userObj = { ...user, password: undefined };
          set({ user: userObj, token: 'offline-token', isLoading: false });
          await AsyncStorage.setItem('user', JSON.stringify(userObj));
          await AsyncStorage.setItem('token', 'offline-token');
          return true;
        }
      }
      set({ isLoading: false });
      return false;
    }
    
    try {
      const response = await axios.post(`${API_URL}/api/auth/login`, { email, password, role });
      const { user, token } = response.data;
      
      set({ user, token, isLoading: false });
      
      await AsyncStorage.setItem('user', JSON.stringify(user));
      await AsyncStorage.setItem('token', token);
      
      const storedUsers = await AsyncStorage.getItem('offlineUsers');
      const users = storedUsers ? JSON.parse(storedUsers) : [];
      const existingIndex = users.findIndex((u: any) => u.email === email.toLowerCase());
      if (existingIndex >= 0) {
        users[existingIndex] = { ...user, password };
      } else {
        users.push({ ...user, password });
      }
      await AsyncStorage.setItem('offlineUsers', JSON.stringify(users));
      
      return true;
    } catch (error: any) {
      console.error('Login error:', error.response?.data || error.message);
      set({ isLoading: false });
      return false;
    }
  },

  register: async (name, email, password, phone, role) => {
    set({ isLoading: true });
    const { isOnline } = get();
    
    if (!isOnline) {
      const storedUsers = await AsyncStorage.getItem('offlineUsers');
      const users = storedUsers ? JSON.parse(storedUsers) : [];
      
      const newUser = {
        id: `offline-${Date.now()}`,
        name,
        email: email.toLowerCase(),
        phone,
        role,
        password,
        created_at: new Date().toISOString()
      };
      
      users.push(newUser);
      await AsyncStorage.setItem('offlineUsers', JSON.stringify(users));
      
      const userObj = { ...newUser, password: undefined };
      set({ user: userObj, token: 'offline-token', isLoading: false });
      await AsyncStorage.setItem('user', JSON.stringify(userObj));
      await AsyncStorage.setItem('token', 'offline-token');
      
      return true;
    }
    
    try {
      const response = await axios.post(`${API_URL}/api/auth/register`, { name, email, password, phone, role });
      const { user, token } = response.data;
      
      set({ user, token, isLoading: false });
      
      await AsyncStorage.setItem('user', JSON.stringify(user));
      await AsyncStorage.setItem('token', token);
      
      const storedUsers = await AsyncStorage.getItem('offlineUsers');
      const users = storedUsers ? JSON.parse(storedUsers) : [];
      users.push({ ...user, password });
      await AsyncStorage.setItem('offlineUsers', JSON.stringify(users));
      
      return true;
    } catch (error: any) {
      console.error('Register error:', error.response?.data || error.message);
      set({ isLoading: false });
      return false;
    }
  },

  logout: async () => {
    set({ user: null, token: null, selectedRole: null, rides: [], currentDestination: null, activeRide: null });
    await AsyncStorage.multiRemove(['user', 'token']);
  },

  requestRide: async () => {
    const { user, token, currentDestination, isOnline, pendingRides } = get();
    if (!user || !currentDestination) return null;
    
    const localId = `local-${Date.now()}`;
    const rideData = {
      destination_label: currentDestination.label,
      destination_x: currentDestination.xPercent,
      destination_y: currentDestination.yPercent,
      fare: currentDestination.fare,
      pickup_location: 'Downtown Plaza',
      local_id: localId
    };
    
    if (!isOnline) {
      const offlineRide: Ride = {
        id: localId,
        user_id: user.id,
        user_name: user.name,
        ...rideData,
        status: 'pending (offline)',
        driver_name: 'Pending sync...',
        driver_eta: undefined,
        created_at: new Date().toISOString(),
        synced: false
      };
      
      const newPending = [...pendingRides, offlineRide];
      set({ pendingRides: newPending, currentDestination: null });
      await AsyncStorage.setItem('pendingRides', JSON.stringify(newPending));
      
      return offlineRide;
    }
    
    try {
      const response = await axios.post(`${API_URL}/api/rides`, rideData, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const newRide = response.data;
      const { rides } = get();
      const updatedRides = [newRide, ...rides];
      set({ rides: updatedRides, currentDestination: null });
      await AsyncStorage.setItem('rides', JSON.stringify(updatedRides));
      
      return newRide;
    } catch (error: any) {
      console.error('Request ride error:', error.response?.data || error.message);
      return null;
    }
  },

  loadRides: async () => {
    const { token, isOnline } = get();
    if (!token || !isOnline) return;
    
    try {
      const response = await axios.get(`${API_URL}/api/rides`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      set({ rides: response.data });
      await AsyncStorage.setItem('rides', JSON.stringify(response.data));
    } catch (error: any) {
      console.error('Load rides error:', error.response?.data || error.message);
    }
  },

  cancelRide: async (rideId) => {
    const { token, rides, pendingRides, isOnline } = get();
    
    if (rideId.startsWith('local-')) {
      const newPending = pendingRides.filter(r => r.id !== rideId);
      set({ pendingRides: newPending });
      await AsyncStorage.setItem('pendingRides', JSON.stringify(newPending));
      return;
    }
    
    if (!isOnline) return;
    
    try {
      await axios.delete(`${API_URL}/api/rides/${rideId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const updatedRides = rides.map(r => 
        r.id === rideId ? { ...r, status: 'cancelled' } : r
      );
      set({ rides: updatedRides });
      await AsyncStorage.setItem('rides', JSON.stringify(updatedRides));
    } catch (error: any) {
      console.error('Cancel ride error:', error.response?.data || error.message);
    }
  },

  syncData: async () => {
    const { token, pendingRides, isOnline } = get();
    if (!token || !isOnline || pendingRides.length === 0) return;
    
    try {
      const ridesToSync = pendingRides.map(r => ({
        destination_label: r.destination_label,
        destination_x: r.destination_x,
        destination_y: r.destination_y,
        fare: r.fare,
        pickup_location: r.pickup_location,
        local_id: r.local_id || r.id
      }));
      
      const response = await axios.post(`${API_URL}/api/sync`, {
        rides: ridesToSync,
        last_sync: null
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const { synced_rides, server_rides } = response.data;
      
      const { rides } = get();
      const allRides = [...synced_rides, ...server_rides, ...rides];
      const uniqueRides = allRides.filter((ride, index, self) =>
        index === self.findIndex(r => r.id === ride.id)
      );
      
      set({ rides: uniqueRides, pendingRides: [] });
      await AsyncStorage.setItem('rides', JSON.stringify(uniqueRides));
      await AsyncStorage.setItem('pendingRides', '[]');
    } catch (error: any) {
      console.error('Sync error:', error.response?.data || error.message);
    }
  },

  loadMessages: async (rideId) => {
    const { token, isOnline } = get();
    if (!token || !isOnline) return [];
    try {
      const response = await axios.get(`${API_URL}/api/rides/${rideId}/messages`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      return response.data;
    } catch (error: any) {
      console.error('Load messages error:', error.response?.data || error.message);
      return [];
    }
  },

  sendMessage: async (rideId, text) => {
    const { token, isOnline } = get();
    if (!token || !isOnline) return;
    try {
      await axios.post(`${API_URL}/api/rides/${rideId}/messages`, { text }, {
        headers: { Authorization: `Bearer ${token}` }
      });
    } catch (error: any) {
      console.error('Send message error:', error.response?.data || error.message);
    }
  }
}));
