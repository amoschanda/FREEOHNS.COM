import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useStore } from '../src/store';
import { Ionicons } from '@expo/vector-icons';

export default function HistoryScreen() {
  const router = useRouter();
  const { rides, pendingRides, loadRides, isOnline, user } = useStore();
  const [refreshing, setRefreshing] = React.useState(false);

  useEffect(() => {
    if (!user) {
      router.replace('/');
    }
  }, [user]);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadRides();
    setRefreshing(false);
  };

  const allRides = [...pendingRides, ...rides];

  const getStatusColor = (status: string) => {
    if (status.includes('pending')) return '#ffd447';
    if (status === 'completed') return '#76dba3';
    if (status === 'cancelled') return '#ff6b6b';
    if (status === 'in_progress') return '#4dabf7';
    return '#9ba5c1';
  };

  const getStatusIcon = (status: string): keyof typeof Ionicons.glyphMap => {
    if (status.includes('pending')) return 'time-outline';
    if (status === 'completed') return 'checkmark-circle-outline';
    if (status === 'cancelled') return 'close-circle-outline';
    if (status === 'in_progress') return 'car-outline';
    return 'ellipse-outline';
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#ffd447" />
        </TouchableOpacity>
        <Text style={styles.title}>Ride History</Text>
        <View style={styles.placeholder} />
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <Ionicons name="car" size={24} color="#ffd447" />
          <Text style={styles.statValue}>{allRides.length}</Text>
          <Text style={styles.statLabel}>Total Rides</Text>
        </View>
        <View style={styles.statCard}>
          <Ionicons name="cash" size={24} color="#76dba3" />
          <Text style={styles.statValue}>
            ${allRides.reduce((sum, r) => sum + r.fare, 0).toFixed(0)}
          </Text>
          <Text style={styles.statLabel}>Total Spent</Text>
        </View>
      </View>

      {/* Rides List */}
      <ScrollView
        style={styles.ridesList}
        contentContainerStyle={styles.ridesContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#ffd447"
          />
        }
      >
        {allRides.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="car-outline" size={64} color="#9ba5c1" />
            <Text style={styles.emptyTitle}>No rides yet</Text>
            <Text style={styles.emptySubtitle}>
              Your ride history will appear here
            </Text>
          </View>
        ) : (
          allRides.map((ride, index) => (
            <View key={ride.id || index} style={styles.rideCard}>
              <View style={styles.rideHeader}>
                <View style={styles.rideDestination}>
                  <Ionicons name="location" size={20} color="#ff6b6b" />
                  <Text style={styles.rideDestText}>{ride.destination_label}</Text>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: `${getStatusColor(ride.status)}20` }]}>
                  <Ionicons name={getStatusIcon(ride.status)} size={14} color={getStatusColor(ride.status)} />
                  <Text style={[styles.statusText, { color: getStatusColor(ride.status) }]}>
                    {ride.status.replace('_', ' ')}
                  </Text>
                </View>
              </View>

              <View style={styles.rideDetails}>
                <View style={styles.rideDetailItem}>
                  <Ionicons name="navigate-outline" size={16} color="#9ba5c1" />
                  <Text style={styles.rideDetailText}>{ride.pickup_location}</Text>
                </View>
                <View style={styles.rideDetailItem}>
                  <Ionicons name="person-outline" size={16} color="#9ba5c1" />
                  <Text style={styles.rideDetailText}>{ride.driver_name || 'Assigning...'}</Text>
                </View>
                <View style={styles.rideDetailItem}>
                  <Ionicons name="time-outline" size={16} color="#9ba5c1" />
                  <Text style={styles.rideDetailText}>{formatDate(ride.created_at)}</Text>
                </View>
              </View>

              <View style={styles.rideFareRow}>
                <Text style={styles.fareLabel}>Fare</Text>
                <Text style={styles.fareAmount}>USD {ride.fare.toFixed(2)}</Text>
              </View>

              {ride.synced === false && (
                <View style={styles.syncBadge}>
                  <Ionicons name="cloud-offline-outline" size={14} color="#ff6b6b" />
                  <Text style={styles.syncText}>Pending sync</Text>
                </View>
              )}
            </View>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#03040a',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: '#f7f9ff',
  },
  placeholder: {
    width: 44,
  },
  statsRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#0f1422',
    borderRadius: 20,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.06)',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#f7f9ff',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#9ba5c1',
    marginTop: 4,
  },
  ridesList: {
    flex: 1,
  },
  ridesContent: {
    padding: 20,
    paddingTop: 8,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#f7f9ff',
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#9ba5c1',
    marginTop: 8,
  },
  rideCard: {
    backgroundColor: '#0f1422',
    borderRadius: 20,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.06)',
  },
  rideHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  rideDestination: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  rideDestText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f7f9ff',
    flex: 1,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 12,
    gap: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
    textTransform: 'capitalize',
  },
  rideDetails: {
    gap: 8,
    marginBottom: 12,
  },
  rideDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  rideDetailText: {
    fontSize: 13,
    color: '#9ba5c1',
  },
  rideFareRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.05)',
  },
  fareLabel: {
    fontSize: 14,
    color: '#9ba5c1',
  },
  fareAmount: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffd447',
  },
  syncBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 107, 107, 0.15)',
    borderRadius: 8,
    paddingVertical: 6,
    marginTop: 12,
    gap: 6,
  },
  syncText: {
    fontSize: 12,
    color: '#ff6b6b',
  },
});
