import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useStore } from '../src/store';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');
const MAP_SIZE = width - 64;

export default function DashboardScreen() {
  const router = useRouter();
  const {
    user,
    logout,
    isOnline,
    currentDestination,
    setDestination,
    requestRide,
    rides,
    pendingRides,
    loadRides,
    syncData,
    isLoading,
    activeRide,
    setActiveRide,
  } = useStore();

  const [statusMessage, setStatusMessage] = useState('Tap the map to choose your drop-off.');
  const [statusType, setStatusType] = useState<'ready' | 'warn' | 'success'>('ready');
  const [markerPosition, setMarkerPosition] = useState<{ x: number; y: number } | null>(null);
  const [driverEta, setDriverEta] = useState(Math.floor(Math.random() * 4) + 3);
  const [isRequesting, setIsRequesting] = useState(false);
  
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 400,
      useNativeDriver: true,
    }).start();
  }, []);

  useEffect(() => {
    if (activeRide) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.2, duration: 800, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
        ])
      ).start();
    }
  }, [activeRide]);

  useEffect(() => {
    const checkUser = async () => {
      await new Promise(resolve => setTimeout(resolve, 100));
      if (!user) {
        router.replace('/');
      } else {
        loadRides();
      }
    };
    checkUser();
  }, [user]);

  useEffect(() => {
    if (isOnline) {
      syncData();
    }
  }, [isOnline]);

  const handleLogout = async () => {
    await logout();
    router.replace('/');
  };

  const handleMapPress = (event: any) => {
    const { locationX, locationY } = event.nativeEvent;
    const xPercent = (locationX / MAP_SIZE) * 100;
    const yPercent = (locationY / MAP_SIZE) * 100;

    setMarkerPosition({ x: locationX, y: locationY });

    const label = describeZone(xPercent, yPercent);
    const fare = calculateFare(xPercent, yPercent);

    setDestination({ label, fare, xPercent, yPercent });
    setStatusMessage(`Route locked to ${label}. Hit Request Ride when ready.`);
    setStatusType('ready');
  };

  const describeZone = (x: number, y: number): string => {
    const horizontal = x < 33 ? 'West' : x < 66 ? 'Central' : 'East';
    const vertical = y < 33 ? 'North' : y < 66 ? 'Mid' : 'South';
    return `${vertical} ${horizontal} District`;
  };

  const calculateFare = (x: number, y: number): number => {
    const distanceFactor = Math.hypot(x - 50, y - 50) / 70;
    return Math.max(4, 4 + distanceFactor * 8);
  };

  const handleRequestRide = async () => {
    if (!currentDestination) {
      setStatusMessage('Please set a destination first.');
      setStatusType('warn');
      return;
    }

    setIsRequesting(true);
    const ride = await requestRide();
    setIsRequesting(false);
    
    if (ride) {
      setActiveRide(ride);
      const eta = ride.driver_eta || Math.floor(Math.random() * 4) + 2;
      setStatusMessage(
        `Ride booked! ${ride.driver_name || 'Driver'} is ${eta} min away.`
      );
      setStatusType('success');
      setMarkerPosition(null);
      setDriverEta(Math.floor(Math.random() * 4) + 3);
      
      // Navigate to tracking after brief delay
      setTimeout(() => {
        router.push('/tracking');
      }, 1500);
    } else {
      setStatusMessage('Failed to book ride. Please try again.');
      setStatusType('warn');
    }
  };

  const recentRides = [...rides, ...pendingRides].slice(0, 5);

  return (
    <SafeAreaView style={styles.container}>
      <Animated.ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        style={{ opacity: fadeAnim }}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.menuButton} onPress={() => router.push('/profile')}>
            <Ionicons name="menu" size={24} color="#ffd447" />
          </TouchableOpacity>
          <Text style={styles.logo}>PULSERIDE</Text>
          <TouchableOpacity style={styles.historyButton} onPress={() => router.push('/history')}>
            <Ionicons name="time-outline" size={22} color="#f7f9ff" />
          </TouchableOpacity>
        </View>

        {/* User Welcome */}
        <View style={styles.welcomeSection}>
          <Text style={styles.welcomeText}>Hello, {user?.name?.split(' ')[0] || 'there'}!</Text>
          <View style={[styles.connectionDot, isOnline ? styles.onlineDot : styles.offlineDot]} />
        </View>

        {/* Active Ride Banner */}
        {activeRide && (
          <TouchableOpacity 
            style={styles.activeRideBanner}
            onPress={() => router.push('/tracking')}
            activeOpacity={0.8}
          >
            <Animated.View style={[styles.pulseCircle, { transform: [{ scale: pulseAnim }] }]} />
            <Ionicons name="car" size={24} color="#ffd447" />
            <View style={styles.activeRideInfo}>
              <Text style={styles.activeRideTitle}>Ride in Progress</Text>
              <Text style={styles.activeRideSubtitle}>{activeRide.driver_name}</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#ffd447" />
          </TouchableOpacity>
        )}

        {/* Hero Card */}
        <View style={styles.heroCard}>
          <View style={styles.heroHeader}>
            <View>
              <Text style={styles.eyebrow}>NEAREST DRIVER</Text>
              <Text style={styles.driverName}>Leo • Prius Prime</Text>
            </View>
            <View style={styles.ratingBadge}>
              <Ionicons name="star" size={14} color="#ffd447" />
              <Text style={styles.ratingText}>4.9</Text>
            </View>
          </View>
          <View style={styles.driverStats}>
            <View style={styles.statItem}>
              <Ionicons name="time-outline" size={18} color="#76dba3" />
              <Text style={styles.statValue}>{driverEta} min</Text>
              <Text style={styles.statLabel}>Away</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Ionicons name="car-outline" size={18} color="#76dba3" />
              <Text style={styles.statValue}>1,240</Text>
              <Text style={styles.statLabel}>Trips</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Ionicons name="shield-checkmark-outline" size={18} color="#76dba3" />
              <Text style={styles.statValue}>Verified</Text>
              <Text style={styles.statLabel}>Driver</Text>
            </View>
          </View>
        </View>

        {/* Map Card */}
        <View style={styles.mapCard}>
          <View style={styles.mapHeader}>
            <Text style={styles.mapTitle}>Set Destination</Text>
            <Text style={styles.mapHint}>Tap on the map</Text>
          </View>
          <TouchableOpacity
            style={styles.map}
            onPress={handleMapPress}
            activeOpacity={0.95}
          >
            <View style={styles.gridContainer}>
              {[...Array(8)].map((_, i) => (
                <View key={`h-${i}`} style={[styles.gridLineH, { top: `${(i + 1) * 12.5}%` }]} />
              ))}
              {[...Array(8)].map((_, i) => (
                <View key={`v-${i}`} style={[styles.gridLineV, { left: `${(i + 1) * 12.5}%` }]} />
              ))}
            </View>

            {markerPosition && (
              <View
                style={[
                  styles.marker,
                  { left: markerPosition.x - 17, top: markerPosition.y - 34 },
                ]}
              >
                <Ionicons name="location" size={34} color="#ff6b6b" />
              </View>
            )}

            <View style={styles.pickupMarker}>
              <View style={styles.pickupPulse} />
              <Ionicons name="radio-button-on" size={20} color="#ffd447" />
            </View>

            {markerPosition && (
              <View style={styles.routeLine} />
            )}
          </TouchableOpacity>

          <View style={styles.mapLegends}>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: '#ffd447' }]} />
              <Text style={styles.legendText}>Pickup</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: '#ff6b6b' }]} />
              <Text style={styles.legendText}>Drop-off</Text>
            </View>
          </View>
        </View>

        {/* Trip Details */}
        <View style={styles.tripDetails}>
          <View style={styles.tripHeader}>
            <Ionicons name="navigate-outline" size={20} color="#ffd447" />
            <Text style={styles.tripTitle}>Trip Summary</Text>
          </View>
          
          <View style={styles.locationRow}>
            <View style={styles.locationIcon}>
              <View style={[styles.locationDot, { backgroundColor: '#ffd447' }]} />
              <View style={styles.locationLine} />
              <View style={[styles.locationDot, { backgroundColor: '#ff6b6b' }]} />
            </View>
            <View style={styles.locationDetails}>
              <View style={styles.locationItem}>
                <Text style={styles.locationLabel}>PICKUP</Text>
                <Text style={styles.locationValue}>Downtown Plaza</Text>
              </View>
              <View style={styles.locationItem}>
                <Text style={styles.locationLabel}>DROP-OFF</Text>
                <Text style={styles.locationValue}>
                  {currentDestination?.label || 'Select on map'}
                </Text>
              </View>
            </View>
          </View>

          <View style={styles.fareRow}>
            <View style={styles.fareItem}>
              <Text style={styles.fareLabel}>Distance</Text>
              <Text style={styles.fareValue}>
                {currentDestination ? `${(currentDestination.fare / 2).toFixed(1)} km` : '-- km'}
              </Text>
            </View>
            <View style={styles.fareItem}>
              <Text style={styles.fareLabel}>Est. Time</Text>
              <Text style={styles.fareValue}>
                {currentDestination ? `${Math.ceil(currentDestination.fare * 1.5)} min` : '-- min'}
              </Text>
            </View>
            <View style={styles.fareItem}>
              <Text style={styles.fareLabel}>Fare</Text>
              <Text style={styles.fareValueHighlight}>
                ${currentDestination ? currentDestination.fare.toFixed(2) : '--'}
              </Text>
            </View>
          </View>
        </View>

        {/* Request Button */}
        <TouchableOpacity
          style={[styles.requestBtn, !currentDestination && styles.requestBtnDisabled]}
          onPress={handleRequestRide}
          disabled={!currentDestination || isRequesting}
          activeOpacity={0.8}
        >
          {isRequesting ? (
            <ActivityIndicator color="#0f1422" size="small" />
          ) : (
            <>
              <Ionicons name="car" size={20} color="#0f1422" />
              <Text style={styles.requestBtnText}>Request Ride</Text>
            </>
          )}
        </TouchableOpacity>

        {/* Status Panel */}
        <View
          style={[
            styles.statusPanel,
            statusType === 'warn' && styles.statusWarn,
            statusType === 'success' && styles.statusSuccess,
          ]}
        >
          <Ionicons
            name={
              statusType === 'success'
                ? 'checkmark-circle'
                : statusType === 'warn'
                ? 'warning'
                : 'information-circle'
            }
            size={18}
            color={
              statusType === 'success'
                ? '#76dba3'
                : statusType === 'warn'
                ? '#ff6b6b'
                : '#9ba5c1'
            }
          />
          <Text
            style={[
              styles.statusText,
              statusType === 'warn' && styles.statusTextWarn,
              statusType === 'success' && styles.statusTextSuccess,
            ]}
          >
            {statusMessage}
          </Text>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.quickAction} onPress={() => router.push('/history')}>
            <Ionicons name="time" size={22} color="#ffd447" />
            <Text style={styles.quickActionText}>History</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickAction} onPress={() => router.push('/profile')}>
            <Ionicons name="person" size={22} color="#ffd447" />
            <Text style={styles.quickActionText}>Profile</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickAction} onPress={handleLogout}>
            <Ionicons name="log-out" size={22} color="#ff6b6b" />
            <Text style={[styles.quickActionText, { color: '#ff6b6b' }]}>Logout</Text>
          </TouchableOpacity>
        </View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#03040a',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  menuButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 4,
    color: '#ffd447',
  },
  historyButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  welcomeSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    gap: 8,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: '700',
    color: '#f7f9ff',
  },
  connectionDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  onlineDot: {
    backgroundColor: '#76dba3',
  },
  offlineDot: {
    backgroundColor: '#ff6b6b',
  },
  activeRideBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 212, 71, 0.15)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    gap: 12,
  },
  pulseCircle: {
    position: 'absolute',
    left: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 212, 71, 0.2)',
  },
  activeRideInfo: {
    flex: 1,
  },
  activeRideTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffd447',
  },
  activeRideSubtitle: {
    fontSize: 12,
    color: '#9ba5c1',
  },
  heroCard: {
    backgroundColor: '#0f1422',
    borderRadius: 24,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.06)',
    marginBottom: 16,
  },
  heroHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  eyebrow: {
    fontSize: 11,
    color: '#9ba5c1',
    letterSpacing: 2,
    marginBottom: 4,
  },
  driverName: {
    fontSize: 20,
    fontWeight: '700',
    color: '#f7f9ff',
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 212, 71, 0.15)',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 12,
    gap: 4,
  },
  ratingText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#ffd447',
  },
  driverStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 16,
    paddingVertical: 16,
  },
  statItem: {
    alignItems: 'center',
    gap: 4,
  },
  statValue: {
    fontSize: 15,
    fontWeight: '600',
    color: '#f7f9ff',
  },
  statLabel: {
    fontSize: 11,
    color: '#9ba5c1',
  },
  statDivider: {
    width: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  mapCard: {
    backgroundColor: '#0f1422',
    borderRadius: 24,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.06)',
    marginBottom: 16,
  },
  mapHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  mapTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f7f9ff',
  },
  mapHint: {
    fontSize: 12,
    color: '#9ba5c1',
  },
  map: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: 20,
    backgroundColor: '#050b1a',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
    overflow: 'hidden',
    position: 'relative',
  },
  gridContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  gridLineH: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.04)',
  },
  gridLineV: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.04)',
  },
  marker: {
    position: 'absolute',
    zIndex: 10,
  },
  pickupMarker: {
    position: 'absolute',
    left: '50%',
    top: '60%',
    marginLeft: -10,
    marginTop: -10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pickupPulse: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 212, 71, 0.2)',
  },
  routeLine: {
    position: 'absolute',
    left: '50%',
    top: '30%',
    width: 2,
    height: '30%',
    backgroundColor: 'rgba(255, 212, 71, 0.3)',
  },
  mapLegends: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 12,
    gap: 24,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  legendText: {
    fontSize: 12,
    color: '#9ba5c1',
  },
  tripDetails: {
    backgroundColor: '#0f1422',
    borderRadius: 24,
    padding: 18,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
    marginBottom: 16,
  },
  tripHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  tripTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f7f9ff',
  },
  locationRow: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  locationIcon: {
    alignItems: 'center',
    marginRight: 12,
    paddingVertical: 4,
  },
  locationDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  locationLine: {
    width: 2,
    height: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    marginVertical: 4,
  },
  locationDetails: {
    flex: 1,
    justifyContent: 'space-between',
  },
  locationItem: {
    marginBottom: 8,
  },
  locationLabel: {
    fontSize: 10,
    color: '#9ba5c1',
    letterSpacing: 1,
    marginBottom: 2,
  },
  locationValue: {
    fontSize: 14,
    color: '#f7f9ff',
    fontWeight: '500',
  },
  fareRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 14,
    padding: 14,
  },
  fareItem: {
    alignItems: 'center',
  },
  fareLabel: {
    fontSize: 11,
    color: '#9ba5c1',
    marginBottom: 4,
  },
  fareValue: {
    fontSize: 14,
    color: '#f7f9ff',
    fontWeight: '600',
  },
  fareValueHighlight: {
    fontSize: 18,
    color: '#ffd447',
    fontWeight: '700',
  },
  requestBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffd447',
    borderRadius: 18,
    paddingVertical: 18,
    gap: 10,
  },
  requestBtnDisabled: {
    opacity: 0.4,
  },
  requestBtnText: {
    color: '#0f1422',
    fontSize: 16,
    fontWeight: '700',
  },
  statusPanel: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 18,
    paddingVertical: 14,
    paddingHorizontal: 16,
    marginTop: 14,
    gap: 10,
  },
  statusWarn: {
    backgroundColor: 'rgba(255, 107, 107, 0.15)',
  },
  statusSuccess: {
    backgroundColor: 'rgba(118, 219, 163, 0.15)',
  },
  statusText: {
    flex: 1,
    fontSize: 14,
    color: '#9ba5c1',
  },
  statusTextWarn: {
    color: '#ff6b6b',
  },
  statusTextSuccess: {
    color: '#76dba3',
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 24,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.05)',
  },
  quickAction: {
    alignItems: 'center',
    gap: 6,
  },
  quickActionText: {
    fontSize: 12,
    color: '#9ba5c1',
  },
});
