import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useStore } from '../src/store';
import { Ionicons } from '@expo/vector-icons';

export default function AuthScreen() {
  const router = useRouter();
  const { selectedRole, login, register, isLoading, isOnline } = useStore();
  
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('+260');
  const [alertMessage, setAlertMessage] = useState('');
  const [alertType, setAlertType] = useState<'error' | 'success' | ''>('');

  const showAlert = (message: string, type: 'error' | 'success') => {
    setAlertMessage(message);
    setAlertType(type);
    setTimeout(() => {
      setAlertMessage('');
      setAlertType('');
    }, 3000);
  };

  const handleSignIn = async () => {
    if (!email || !password) {
      showAlert('Please fill in all fields', 'error');
      return;
    }
    
    const success = await login(email, password, selectedRole || 'customer');
    if (success) {
      showAlert('Welcome back!', 'success');
      setTimeout(() => router.replace('/dashboard'), 500);
    } else {
      showAlert('Invalid email or password', 'error');
    }
  };

  const handleSignUp = async () => {
    if (!name || !email || !password || !phone) {
      showAlert('Please fill in all fields', 'error');
      return;
    }
    if (password.length < 6) {
      showAlert('Password must be at least 6 characters', 'error');
      return;
    }
    
    const success = await register(name, email, password, phone, selectedRole || 'customer');
    if (success) {
      showAlert('Account created successfully!', 'success');
      setTimeout(() => router.replace('/dashboard'), 500);
    } else {
      showAlert('Email already registered', 'error');
    }
  };

  const handleForgotPassword = () => {
    showAlert('Reset link sent to your email!', 'success');
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => router.back()}
            >
              <Ionicons name="arrow-back" size={24} color="#ffd447" />
            </TouchableOpacity>
            <Text style={styles.logo}>PULSERIDE</Text>
            <View style={styles.placeholder} />
          </View>

          {/* Offline Banner */}
          {!isOnline && (
            <View style={styles.offlineBanner}>
              <Ionicons name="cloud-offline-outline" size={16} color="#ff6b6b" />
              <Text style={styles.offlineText}>Offline Mode - Data will sync when online</Text>
            </View>
          )}

          {/* Auth Card */}
          <View style={styles.authCard}>
            {/* Tabs */}
            <View style={styles.tabs}>
              <TouchableOpacity
                style={[styles.tab, mode === 'signin' && styles.tabActive]}
                onPress={() => setMode('signin')}
              >
                <Text style={[styles.tabText, mode === 'signin' && styles.tabTextActive]}>
                  Sign In
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.tab, mode === 'signup' && styles.tabActive]}
                onPress={() => setMode('signup')}
              >
                <Text style={[styles.tabText, mode === 'signup' && styles.tabTextActive]}>
                  Sign Up
                </Text>
              </TouchableOpacity>
            </View>

            {/* Sign In Form */}
            {mode === 'signin' && (
              <View style={styles.form}>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Email</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="you@example.com"
                    placeholderTextColor="#6b7280"
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                </View>
                
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Password</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="••••••"
                    placeholderTextColor="#6b7280"
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry
                  />
                </View>

                <TouchableOpacity onPress={handleForgotPassword}>
                  <Text style={styles.forgotLink}>Forgot Password?</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.submitButton}
                  onPress={handleSignIn}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <ActivityIndicator color="#0f1422" />
                  ) : (
                    <Text style={styles.submitText}>Sign In</Text>
                  )}
                </TouchableOpacity>
              </View>
            )}

            {/* Sign Up Form */}
            {mode === 'signup' && (
              <View style={styles.form}>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Full Name</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Jamie Skywalker"
                    placeholderTextColor="#6b7280"
                    value={name}
                    onChangeText={setName}
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Email</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="jamie@domain.com"
                    placeholderTextColor="#6b7280"
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Phone Number</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="+260"
                    placeholderTextColor="#6b7280"
                    value={phone}
                    onChangeText={setPhone}
                    keyboardType="phone-pad"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Password (min 6 characters)</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Choose a strong key"
                    placeholderTextColor="#6b7280"
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry
                  />
                </View>

                <TouchableOpacity
                  style={styles.submitButton}
                  onPress={handleSignUp}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <ActivityIndicator color="#0f1422" />
                  ) : (
                    <Text style={styles.submitText}>Create Account</Text>
                  )}
                </TouchableOpacity>
              </View>
            )}

            {/* Alert */}
            {alertMessage ? (
              <View style={[styles.alert, alertType === 'error' ? styles.alertError : styles.alertSuccess]}>
                <Text style={[styles.alertText, alertType === 'error' ? styles.alertTextError : styles.alertTextSuccess]}>
                  {alertMessage}
                </Text>
              </View>
            ) : null}

            {/* Hint */}
            <Text style={styles.hint}>
              {isOnline ? 'Create a new account to get started' : 'Offline: Using locally stored credentials'}
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#03040a',
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
    marginBottom: 20,
  },
  backButton: {
    padding: 8,
  },
  logo: {
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 4,
    color: '#ffd447',
  },
  placeholder: {
    width: 40,
  },
  offlineBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 107, 107, 0.15)',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 20,
    gap: 8,
  },
  offlineText: {
    color: '#ff6b6b',
    fontSize: 13,
    fontWeight: '500',
  },
  authCard: {
    backgroundColor: '#0f1422',
    borderRadius: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.06)',
    padding: 22,
  },
  tabs: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 999,
    padding: 4,
    marginBottom: 20,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 999,
    alignItems: 'center',
  },
  tabActive: {
    backgroundColor: '#ffd447',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#9ba5c1',
  },
  tabTextActive: {
    color: '#0f1422',
  },
  form: {
    gap: 16,
  },
  inputGroup: {
    gap: 6,
  },
  label: {
    fontSize: 14,
    color: '#9ba5c1',
    fontWeight: '500',
  },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: '#f7f9ff',
    fontSize: 15,
  },
  forgotLink: {
    color: '#ffd447',
    fontSize: 14,
    textAlign: 'center',
    textDecorationLine: 'underline',
    marginTop: 4,
  },
  submitButton: {
    backgroundColor: '#ffd447',
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  submitText: {
    color: '#0f1422',
    fontSize: 16,
    fontWeight: '700',
  },
  alert: {
    marginTop: 16,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  alertError: {
    backgroundColor: 'rgba(255, 107, 107, 0.15)',
  },
  alertSuccess: {
    backgroundColor: 'rgba(118, 219, 163, 0.15)',
  },
  alertText: {
    fontSize: 14,
    fontWeight: '500',
  },
  alertTextError: {
    color: '#ff6b6b',
  },
  alertTextSuccess: {
    color: '#76dba3',
  },
  hint: {
    fontSize: 13,
    color: '#9ba5c1',
    textAlign: 'center',
    marginTop: 16,
  },
});
