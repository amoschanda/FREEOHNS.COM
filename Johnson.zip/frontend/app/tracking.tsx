import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useStore } from '../src/store';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

export default function TrackingScreen() {
  const router = useRouter();
  const { activeRide, setActiveRide, user, cancelRide } = useStore();
  
  const [eta, setEta] = useState(activeRide?.driver_eta || 5);
  const [status, setStatus] = useState<'arriving' | 'arrived' | 'in_progress' | 'completed'>('arriving');
  
  const carPosition = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (!activeRide) {
      router.replace('/dashboard');
      return;
    }

    // Simulate car movement
    Animated.loop(
      Animated.sequence([
        Animated.timing(carPosition, { toValue: 1, duration: 3000, useNativeDriver: true }),
        Animated.timing(carPosition, { toValue: 0, duration: 3000, useNativeDriver: true }),
      ])
    ).start();

    // Pulse animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.3, duration: 1000, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();

    // Simulate ETA countdown
    const interval = setInterval(() => {
      setEta(prev => {
        if (prev <= 1) {
          if (status === 'arriving') {
            setStatus('arrived');
            return 0;
          }
        }
        return Math.max(0, prev - 1);
      });
    }, 60000); // Every minute

    // Simulate status progression for demo
    const statusTimer = setTimeout(() => {
      if (status === 'arriving') {
        setStatus('arrived');
      }
    }, 10000);

    return () => {
      clearInterval(interval);
      clearTimeout(statusTimer);
    };
  }, [activeRide, status]);

  const handleCancel = async () => {
    if (activeRide) {
      await cancelRide(activeRide.id);
    }
    setActiveRide(null);
    router.replace('/dashboard');
  };

  const handleComplete = () => {
    setActiveRide(null);
    router.replace('/dashboard');
  };

  const getStatusInfo = () => {
    switch (status) {
      case 'arriving':
        return { title: 'Driver is on the way', subtitle: `Arriving in ${eta} min`, color: '#ffd447' };
      case 'arrived':
        return { title: 'Driver has arrived', subtitle: 'Meet at pickup point', color: '#76dba3' };
      case 'in_progress':
        return { title: 'Trip in progress', subtitle: 'Enjoy your ride', color: '#4dabf7' };
      case 'completed':
        return { title: 'Trip completed', subtitle: 'Thank you for riding', color: '#76dba3' };
    }
  };

  const statusInfo = getStatusInfo();

  if (!activeRide) return null;

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Ionicons name="chevron-down" size={28} color="#ffd447" />
        </TouchableOpacity>
        <Text style={styles.title}>Live Tracking</Text>
        <View style={styles.placeholder} />
      </View>

      {/* Map Area */}
      <View style={styles.mapArea}>
        <View style={styles.mapPlaceholder}>
          {/* Grid */}
          {[...Array(10)].map((_, i) => (
            <View key={`h-${i}`} style={[styles.gridLine, { top: `${i * 10}%` }]} />
          ))}
          {[...Array(10)].map((_, i) => (
            <View key={`v-${i}`} style={[styles.gridLineV, { left: `${i * 10}%` }]} />
          ))}

          {/* Pickup marker */}
          <Animated.View style={[styles.pickupMarker, { transform: [{ scale: pulseAnim }] }]}>
            <View style={styles.pickupPulse} />
          </Animated.View>
          <View style={styles.pickupIcon}>
            <Ionicons name="radio-button-on" size={24} color="#ffd447" />
          </View>

          {/* Destination marker */}
          <View style={styles.destinationMarker}>
            <Ionicons name="location" size={32} color="#ff6b6b" />
          </View>

          {/* Car icon */}
          <Animated.View
            style={[
              styles.carMarker,
              {
                transform: [
                  {
                    translateX: carPosition.interpolate({
                      inputRange: [0, 1],
                      outputRange: [-20, 20],
                    }),
                  },
                  {
                    translateY: carPosition.interpolate({
                      inputRange: [0, 1],
                      outputRange: [10, -10],
                    }),
                  },
                ],
              },
            ]}
          >
            <View style={styles.carIconContainer}>
              <Ionicons name="car" size={24} color="#ffd447" />
            </View>
          </Animated.View>

          {/* Route line */}
          <View style={styles.routeLine} />
        </View>
      </View>

      {/* Status Card */}
      <View style={styles.statusCard}>
        <View style={[styles.statusIndicator, { backgroundColor: statusInfo.color }]} />
        <View style={styles.statusContent}>
          <Text style={styles.statusTitle}>{statusInfo.title}</Text>
          <Text style={styles.statusSubtitle}>{statusInfo.subtitle}</Text>
        </View>
        {status === 'arriving' && (
          <View style={styles.etaBadge}>
            <Text style={styles.etaValue}>{eta}</Text>
            <Text style={styles.etaLabel}>MIN</Text>
          </View>
        )}
      </View>

      {/* Driver Info */}
      <View style={styles.driverCard}>
        <View style={styles.driverAvatar}>
          <Text style={styles.driverAvatarText}>
            {activeRide.driver_name?.charAt(0) || 'D'}
          </Text>
        </View>
        <View style={styles.driverInfo}>
          <Text style={styles.driverName}>{activeRide.driver_name || 'Driver'}</Text>
          <View style={styles.driverRating}>
            <Ionicons name="star" size={14} color="#ffd447" />
            <Text style={styles.driverRatingText}>4.9</Text>
          </View>
        </View>
        <View style={styles.driverActions}>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="call" size={20} color="#76dba3" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => router.push({ pathname: '/chat', params: { rideId: activeRide.id } })}
          >
            <Ionicons name="chatbubble" size={20} color="#4dabf7" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Trip Details */}
      <View style={styles.tripCard}>
        <View style={styles.tripRow}>
          <View style={styles.tripLocation}>
            <View style={[styles.tripDot, { backgroundColor: '#ffd447' }]} />
            <Text style={styles.tripLocationText}>{activeRide.pickup_location}</Text>
          </View>
          <Text style={styles.tripFare}>${activeRide.fare.toFixed(2)}</Text>
        </View>
        <View style={styles.tripDivider} />
        <View style={styles.tripRow}>
          <View style={styles.tripLocation}>
            <View style={[styles.tripDot, { backgroundColor: '#ff6b6b' }]} />
            <Text style={styles.tripLocationText}>{activeRide.destination_label}</Text>
          </View>
        </View>
      </View>

      {/* Action Buttons */}
      <View style={styles.actionRow}>
        {status !== 'completed' ? (
          <>
            <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
              <Ionicons name="close-circle" size={20} color="#ff6b6b" />
              <Text style={styles.cancelText}>Cancel Ride</Text>
            </TouchableOpacity>
            {status === 'arrived' && (
              <TouchableOpacity 
                style={styles.startButton}
                onPress={() => setStatus('in_progress')}
              >
                <Ionicons name="play-circle" size={20} color="#0f1422" />
                <Text style={styles.startText}>Start Trip</Text>
              </TouchableOpacity>
            )}
            {status === 'in_progress' && (
              <TouchableOpacity 
                style={styles.completeButton}
                onPress={() => setStatus('completed')}
              >
                <Ionicons name="checkmark-circle" size={20} color="#0f1422" />
                <Text style={styles.completeText}>Complete</Text>
              </TouchableOpacity>
            )}
          </>
        ) : (
          <TouchableOpacity style={styles.doneButton} onPress={handleComplete}>
            <Ionicons name="home" size={20} color="#0f1422" />
            <Text style={styles.doneText}>Back to Home</Text>
          </TouchableOpacity>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#03040a',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: '#f7f9ff',
  },
  placeholder: {
    width: 44,
  },
  mapArea: {
    height: 200,
    marginHorizontal: 20,
    marginBottom: 16,
  },
  mapPlaceholder: {
    flex: 1,
    backgroundColor: '#0a0f1a',
    borderRadius: 20,
    overflow: 'hidden',
    position: 'relative',
  },
  gridLine: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
  },
  gridLineV: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
  },
  pickupMarker: {
    position: 'absolute',
    left: '30%',
    top: '60%',
    width: 40,
    height: 40,
    marginLeft: -20,
    marginTop: -20,
  },
  pickupPulse: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 212, 71, 0.2)',
  },
  pickupIcon: {
    position: 'absolute',
    left: '30%',
    top: '60%',
    marginLeft: -12,
    marginTop: -12,
  },
  destinationMarker: {
    position: 'absolute',
    right: '25%',
    top: '30%',
  },
  carMarker: {
    position: 'absolute',
    left: '45%',
    top: '45%',
  },
  carIconContainer: {
    backgroundColor: 'rgba(255, 212, 71, 0.2)',
    padding: 8,
    borderRadius: 20,
  },
  routeLine: {
    position: 'absolute',
    left: '32%',
    top: '35%',
    width: '35%',
    height: 2,
    backgroundColor: 'rgba(255, 212, 71, 0.3)',
    transform: [{ rotate: '-30deg' }],
  },
  statusCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#0f1422',
    marginHorizontal: 20,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
  },
  statusIndicator: {
    width: 4,
    height: 40,
    borderRadius: 2,
    marginRight: 14,
  },
  statusContent: {
    flex: 1,
  },
  statusTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f7f9ff',
  },
  statusSubtitle: {
    fontSize: 13,
    color: '#9ba5c1',
    marginTop: 2,
  },
  etaBadge: {
    alignItems: 'center',
    backgroundColor: 'rgba(255, 212, 71, 0.15)',
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 12,
  },
  etaValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#ffd447',
  },
  etaLabel: {
    fontSize: 10,
    color: '#ffd447',
  },
  driverCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#0f1422',
    marginHorizontal: 20,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
  },
  driverAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255, 212, 71, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  driverAvatarText: {
    fontSize: 20,
    fontWeight: '700',
    color: '#ffd447',
  },
  driverInfo: {
    flex: 1,
    marginLeft: 14,
  },
  driverName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f7f9ff',
  },
  driverRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  driverRatingText: {
    fontSize: 13,
    color: '#9ba5c1',
  },
  driverActions: {
    flexDirection: 'row',
    gap: 10,
  },
  actionButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tripCard: {
    backgroundColor: '#0f1422',
    marginHorizontal: 20,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
  },
  tripRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  tripLocation: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  tripDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  tripLocationText: {
    fontSize: 14,
    color: '#f7f9ff',
  },
  tripFare: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffd447',
  },
  tripDivider: {
    height: 24,
    width: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    marginLeft: 4,
    marginVertical: 8,
  },
  actionRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 12,
    marginTop: 'auto',
    marginBottom: 20,
  },
  cancelButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 107, 107, 0.15)',
    borderRadius: 16,
    paddingVertical: 16,
    gap: 8,
  },
  cancelText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#ff6b6b',
  },
  startButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4dabf7',
    borderRadius: 16,
    paddingVertical: 16,
    gap: 8,
  },
  startText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0f1422',
  },
  completeButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#76dba3',
    borderRadius: 16,
    paddingVertical: 16,
    gap: 8,
  },
  completeText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0f1422',
  },
  doneButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffd447',
    borderRadius: 16,
    paddingVertical: 16,
    gap: 8,
  },
  doneText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0f1422',
  },
});
