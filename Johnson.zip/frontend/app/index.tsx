import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions, Animated } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useStore } from '../src/store';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

export default function RoleSelectScreen() {
  const router = useRouter();
  const { setSelectedRole, user, isOnline } = useStore();
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (user) {
      router.replace('/dashboard');
    }
  }, [user]);

  const handleRoleSelect = (role: string) => {
    setSelectedRole(role);
    router.push('/auth');
  };

  const roles = [
    { id: 'customer', label: 'Customer', icon: 'person-outline' as const, color: '#ffd447', desc: 'Book rides' },
    { id: 'driver', label: 'Driver', icon: 'car-outline' as const, color: '#76dba3', desc: 'Accept trips' },
    { id: 'admin', label: 'Admin', icon: 'settings-outline' as const, color: '#9ba5c1', desc: 'Manage all' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        {/* Online/Offline Banner */}
        <View style={[styles.statusBanner, isOnline ? styles.onlineBanner : styles.offlineBanner]}>
          <Ionicons 
            name={isOnline ? "cloud-done-outline" : "cloud-offline-outline"} 
            size={16} 
            color={isOnline ? "#76dba3" : "#ff6b6b"} 
          />
          <Text style={[styles.statusText, isOnline ? styles.onlineText : styles.offlineText]}>
            {isOnline ? 'Connected' : 'Offline Mode'}
          </Text>
        </View>

        {/* Logo */}
        <Animated.View style={[styles.logoContainer, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
          <View style={styles.logoIconContainer}>
            <Ionicons name="car-sport" size={48} color="#ffd447" />
          </View>
          <Text style={styles.logo}>PULSERIDE</Text>
          <Text style={styles.tagline}>Premium Taxi Service</Text>
        </Animated.View>

        {/* Role Selection Card */}
        <Animated.View style={[styles.roleCard, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
          <Text style={styles.roleTitle}>Select Your Role</Text>
          <Text style={styles.roleSubtitle}>Choose how you want to use PulseRide</Text>
          
          <View style={styles.roleButtons}>
            {roles.map((role, index) => (
              <TouchableOpacity
                key={role.id}
                style={styles.roleButton}
                onPress={() => handleRoleSelect(role.id)}
                activeOpacity={0.7}
              >
                <View style={[styles.roleIconContainer, { backgroundColor: `${role.color}20` }]}>
                  <Ionicons name={role.icon} size={28} color={role.color} />
                </View>
                <Text style={styles.roleLabel}>{role.label}</Text>
                <Text style={styles.roleDesc}>{role.desc}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Animated.View>

        {/* Features */}
        <Animated.View style={[styles.features, { opacity: fadeAnim }]}>
          <View style={styles.featureItem}>
            <Ionicons name="shield-checkmark" size={20} color="#ffd447" />
            <Text style={styles.featureText}>Safe</Text>
          </View>
          <View style={styles.featureDot} />
          <View style={styles.featureItem}>
            <Ionicons name="flash" size={20} color="#ffd447" />
            <Text style={styles.featureText}>Fast</Text>
          </View>
          <View style={styles.featureDot} />
          <View style={styles.featureItem}>
            <Ionicons name="star" size={20} color="#ffd447" />
            <Text style={styles.featureText}>Reliable</Text>
          </View>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#03040a',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    justifyContent: 'center',
  },
  statusBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginBottom: 24,
    alignSelf: 'center',
    gap: 8,
  },
  onlineBanner: {
    backgroundColor: 'rgba(118, 219, 163, 0.15)',
  },
  offlineBanner: {
    backgroundColor: 'rgba(255, 107, 107, 0.15)',
  },
  statusText: {
    fontSize: 14,
    fontWeight: '600',
  },
  onlineText: {
    color: '#76dba3',
  },
  offlineText: {
    color: '#ff6b6b',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 212, 71, 0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  logo: {
    fontSize: 32,
    fontWeight: '800',
    letterSpacing: 6,
    color: '#ffd447',
  },
  tagline: {
    fontSize: 14,
    color: '#9ba5c1',
    marginTop: 8,
    letterSpacing: 1,
  },
  roleCard: {
    backgroundColor: '#0f1422',
    borderRadius: 24,
    padding: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.06)',
  },
  roleTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#f7f9ff',
    textAlign: 'center',
    marginBottom: 8,
  },
  roleSubtitle: {
    fontSize: 14,
    color: '#9ba5c1',
    textAlign: 'center',
    marginBottom: 24,
  },
  roleButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  roleButton: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    paddingVertical: 20,
    paddingHorizontal: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  roleIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  roleLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#f7f9ff',
  },
  roleDesc: {
    fontSize: 11,
    color: '#9ba5c1',
    marginTop: 4,
  },
  features: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 32,
    gap: 16,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  featureText: {
    fontSize: 13,
    color: '#9ba5c1',
    fontWeight: '500',
  },
  featureDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
});
