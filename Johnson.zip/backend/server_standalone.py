import os
import uuid
import hashlib
import jwt
import sqlite3
import logging
from datetime import datetime, timedelta
from typing import List, Optional
from fastapi import FastAPI, APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, EmailStr
from pathlib import Path

# Constants
JWT_SECRET = 'pulseride-standalone-secret-2024'
JWT_ALGORITHM = 'HS256'
DB_PATH = 'pulseride.db'

# Setup Database
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        phone TEXT NOT NULL,
        role TEXT NOT NULL,
        created_at TEXT NOT NULL
    )
    ''')
    
    # Rides table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS rides (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        destination_label TEXT NOT NULL,
        destination_x REAL NOT NULL,
        destination_y REAL NOT NULL,
        fare REAL NOT NULL,
        pickup_location TEXT NOT NULL,
        status TEXT NOT NULL,
        driver_name TEXT,
        driver_id TEXT,
        driver_eta INTEGER,
        created_at TEXT NOT NULL,
        local_id TEXT,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
    ''')

    # Messages table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY,
        ride_id TEXT NOT NULL,
        sender_id TEXT NOT NULL,
        text TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (ride_id) REFERENCES rides (id),
        FOREIGN KEY (sender_id) REFERENCES users (id)
    )
    ''')
    
    conn.commit()
    conn.close()

init_db()

# Models
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    phone: str
    role: str = "customer"

class UserLogin(BaseModel):
    email: EmailStr
    password: str
    role: str = "customer"

class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    phone: str
    role: str
    created_at: str

class AuthResponse(BaseModel):
    user: UserResponse
    token: str

class RideCreate(BaseModel):
    destination_label: str
    destination_x: float
    destination_y: float
    fare: float
    pickup_location: str = "Downtown Plaza"
    local_id: Optional[str] = None

class RideResponse(BaseModel):
    id: str
    user_id: str
    user_name: str
    destination_label: str
    destination_x: float
    destination_y: float
    fare: float
    pickup_location: str
    status: str
    driver_name: Optional[str] = None
    driver_eta: Optional[int] = None
    created_at: str
    local_id: Optional[str] = None

class RideUpdate(BaseModel):
    status: Optional[str] = None
    driver_name: Optional[str] = None
    driver_eta: Optional[int] = None

class SyncRequest(BaseModel):
    rides: List[RideCreate]
    last_sync: Optional[str] = None

class SyncResponse(BaseModel):
    synced_rides: List[RideResponse]
    server_rides: List[RideResponse]

class MessageCreate(BaseModel):
    text: str

class MessageResponse(BaseModel):
    id: str
    ride_id: str
    sender_id: str
    text: str
    created_at: str

# App Setup
app = FastAPI(title="PulseRide Standalone API")
api_router = APIRouter(prefix="/api")
security = HTTPBearer(auto_error=False)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Helpers
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def create_token(user_id: str, email: str, role: str) -> str:
    payload = {
        'user_id': user_id,
        'email': email,
        'role': role,
        'exp': datetime.utcnow() + timedelta(days=30)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def verify_token(token: str) -> dict:
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Authentication required")
    payload = verify_token(credentials.credentials)
    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    user = conn.execute('SELECT * FROM users WHERE id = ?', (payload['user_id'],)).fetchone()
    conn.close()
    
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return dict(user)

# Routes
@api_router.post("/auth/register", response_model=AuthResponse)
async def register(user_data: UserCreate):
    conn = sqlite3.connect(DB_PATH)
    existing = conn.execute('SELECT * FROM users WHERE email = ?', (user_data.email.lower(),)).fetchone()
    if existing:
        conn.close()
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user_id = str(uuid.uuid4())
    created_at = datetime.utcnow().isoformat()
    conn.execute(
        'INSERT INTO users (id, name, email, password, phone, role, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        (user_id, user_data.name, user_data.email.lower(), hash_password(user_data.password), user_data.phone, user_data.role, created_at)
    )
    conn.commit()
    conn.close()
    
    token = create_token(user_id, user_data.email.lower(), user_data.role)
    return AuthResponse(
        user=UserResponse(id=user_id, name=user_data.name, email=user_data.email.lower(), phone=user_data.phone, role=user_data.role, created_at=created_at),
        token=token
    )

@api_router.post("/auth/login", response_model=AuthResponse)
async def login(login_data: UserLogin):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    user = conn.execute(
        'SELECT * FROM users WHERE email = ? AND password = ?',
        (login_data.email.lower(), hash_password(login_data.password))
    ).fetchone()
    conn.close()
    
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    user_dict = dict(user)
    token = create_token(user_dict['id'], user_dict['email'], user_dict['role'])
    return AuthResponse(
        user=UserResponse(**user_dict),
        token=token
    )

@api_router.get("/auth/me", response_model=UserResponse)
async def get_me(current_user: dict = Depends(get_current_user)):
    return UserResponse(**current_user)

@api_router.post("/rides", response_model=RideResponse)
async def create_ride(ride_data: RideCreate, current_user: dict = Depends(get_current_user)):
    import random
    ride_id = str(uuid.uuid4())
    driver_names = ["Leo", "Maya", "Alex", "Sam", "Jordan"]
    car_types = ["Prius Prime", "Camry Hybrid", "Tesla Model 3", "Civic", "Accord"]
    
    driver_name = f"{random.choice(driver_names)} • {random.choice(car_types)}"
    driver_eta = random.randint(3, 8)
    created_at = datetime.utcnow().isoformat()
    
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        '''INSERT INTO rides (id, user_id, user_name, destination_label, destination_x, destination_y, fare, pickup_location, status, driver_name, driver_eta, created_at, local_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
        (ride_id, current_user['id'], current_user['name'], ride_data.destination_label, ride_data.destination_x, ride_data.destination_y, ride_data.fare, ride_data.pickup_location, 'pending', driver_name, driver_eta, created_at, ride_data.local_id)
    )
    conn.commit()
    conn.close()
    
    return RideResponse(
        id=ride_id, user_id=current_user['id'], user_name=current_user['name'],
        destination_label=ride_data.destination_label, destination_x=ride_data.destination_x,
        destination_y=ride_data.destination_y, fare=ride_data.fare, pickup_location=ride_data.pickup_location,
        status='pending', driver_name=driver_name, driver_eta=driver_eta, created_at=created_at, local_id=ride_data.local_id
    )

@api_router.get("/rides", response_model=List[RideResponse])
async def get_rides(current_user: dict = Depends(get_current_user)):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    if current_user['role'] in ['admin', 'driver']:
        rides = conn.execute('SELECT * FROM rides ORDER BY created_at DESC').fetchall()
    else:
        rides = conn.execute('SELECT * FROM rides WHERE user_id = ? ORDER BY created_at DESC', (current_user['id'],)).fetchall()
    conn.close()
    return [RideResponse(**dict(r)) for r in rides]

@api_router.post("/sync", response_model=SyncResponse)
async def sync_data(sync_data: SyncRequest, current_user: dict = Depends(get_current_user)):
    import random
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    synced_rides = []
    
    for r in sync_data.rides:
        existing = conn.execute('SELECT * FROM rides WHERE local_id = ? AND user_id = ?', (r.local_id, current_user['id'])).fetchone()
        if existing:
            synced_rides.append(RideResponse(**dict(existing)))
        else:
            ride_id = str(uuid.uuid4())
            created_at = datetime.utcnow().isoformat()
            driver = f"{random.choice(['Leo', 'Maya', 'Alex'])} • Prius"
            eta = random.randint(3, 8)
            conn.execute(
                '''INSERT INTO rides (id, user_id, user_name, destination_label, destination_x, destination_y, fare, pickup_location, status, driver_name, driver_eta, created_at, local_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (ride_id, current_user['id'], current_user['name'], r.destination_label, r.destination_x, r.destination_y, r.fare, r.pickup_location, 'pending', driver, eta, created_at, r.local_id)
            )
            synced_rides.append(RideResponse(
                id=ride_id, user_id=current_user['id'], user_name=current_user['name'],
                destination_label=r.destination_label, destination_x=r.destination_x,
                destination_y=r.destination_y, fare=r.fare, pickup_location=r.pickup_location,
                status='pending', driver_name=driver, driver_eta=eta, created_at=created_at, local_id=r.local_id
            ))
    
    conn.commit()
    server_rides = conn.execute('SELECT * FROM rides WHERE user_id = ? ORDER BY created_at DESC', (current_user['id'],)).fetchall()
    conn.close()
    
    return SyncResponse(synced_rides=synced_rides, server_rides=[RideResponse(**dict(r)) for r in server_rides])

@api_router.get("/rides/{ride_id}/messages", response_model=List[MessageResponse])
async def get_messages(ride_id: str, current_user: dict = Depends(get_current_user)):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    messages = conn.execute(
        'SELECT * FROM messages WHERE ride_id = ? ORDER BY created_at ASC',
        (ride_id,)
    ).fetchall()
    conn.close()
    return [MessageResponse(**dict(m)) for m in messages]

@api_router.post("/rides/{ride_id}/messages", response_model=MessageResponse)
async def send_message(ride_id: str, msg: MessageCreate, current_user: dict = Depends(get_current_user)):
    msg_id = str(uuid.uuid4())
    created_at = datetime.utcnow().isoformat()
    
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        'INSERT INTO messages (id, ride_id, sender_id, text, created_at) VALUES (?, ?, ?, ?, ?)',
        (msg_id, ride_id, current_user['id'], msg.text, created_at)
    )
    conn.commit()
    conn.close()
    
    return MessageResponse(
        id=msg_id,
        ride_id=ride_id,
        sender_id=current_user['id'],
        text=msg.text,
        created_at=created_at
    )

@api_router.get("/health")
async def health():
    return {"status": "healthy", "mode": "standalone"}

app.include_router(api_router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
