# PulseRide Standalone App

This is a standalone version of the PulseRide Expo app, refactored for offline-first capability and local builds.

## Features
- **Standalone API**: Uses a local SQLite database (no MongoDB or emergent.sh required).
- **Offline Mode**: Fully functional without an internet connection.
- **Build Ready**: Includes a pre-configured Android project for APK/AAB generation.

## Project Structure
- `frontend/`: The React Native Expo project.
- `backend/`: Standalone FastAPI server with SQLite.
- `dependency.py`: Script to automate environment setup and build preparation.

## How to Build (Linux Terminal)

### 1. Setup Environment
Ensure you have Node.js, Python, and the Android SDK installed.
```bash
python3 dependency.py setup
```

### 2. Run the Standalone API
In a separate terminal:
```bash
cd backend
python3 server_standalone.py
```

### 3. Build the APK
```bash
python3 dependency.py build
cd frontend/android
./gradlew assembleDebug
```
The APK will be generated at `frontend/android/app/build/outputs/apk/debug/app-debug.apk`.

### 4. Build the AAB (for Play Store)
```bash
cd frontend/android
./gradlew bundleRelease
```

## Standalone API Details
The API is located in `backend/server_standalone.py`. It uses `pulseride.db` (SQLite) to store all user and ride data locally. No external cloud services are required.
