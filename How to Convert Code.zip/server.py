from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import bcrypt

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT Settings
SECRET_KEY = os.environ.get('JWT_SECRET', 'freeohns-secret-key-2024')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS = 24

# Admin password
ADMIN_PASSWORD = "Johnson"

# Create the main app
app = FastAPI(title="FREEOHNS API")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

security = HTTPBearer()

# ===================== MODELS =====================

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    phone: str
    role: str = "customer"  # customer, driver, electrician, cleaner

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class AdminLogin(BaseModel):
    password: str

class UserResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    email: str
    full_name: str
    phone: str
    role: str
    created_at: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

class ServiceResponse(BaseModel):
    id: str
    name: str
    slug: str
    description: str
    icon: str
    image_url: str
    features: List[str]

class BookingCreate(BaseModel):
    service_type: str  # taxi, electro_fix, cleaning
    pickup_address: Optional[str] = None
    dropoff_address: Optional[str] = None
    service_address: Optional[str] = None
    scheduled_date: str
    scheduled_time: str
    notes: Optional[str] = None
    # Taxi specific
    vehicle_type: Optional[str] = None
    # Electro fix specific
    issue_type: Optional[str] = None
    # Cleaning specific
    property_type: Optional[str] = None
    cleaning_type: Optional[str] = None

class BookingResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    user_id: str
    user_name: str
    user_phone: str
    service_type: str
    status: str
    pickup_address: Optional[str] = None
    dropoff_address: Optional[str] = None
    service_address: Optional[str] = None
    scheduled_date: str
    scheduled_time: str
    notes: Optional[str] = None
    vehicle_type: Optional[str] = None
    issue_type: Optional[str] = None
    property_type: Optional[str] = None
    cleaning_type: Optional[str] = None
    provider_id: Optional[str] = None
    provider_name: Optional[str] = None
    created_at: str

class BookingUpdate(BaseModel):
    status: Optional[str] = None
    provider_id: Optional[str] = None

class ProviderCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    phone: str
    service_type: str  # taxi, electro_fix, cleaning
    vehicle_info: Optional[str] = None
    experience: Optional[str] = None

# ===================== HELPERS =====================

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        role = payload.get("role")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return {"user_id": user_id, "role": role}
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

# ===================== AUTH ROUTES =====================

@api_router.post("/auth/register", response_model=TokenResponse)
async def register(user: UserCreate):
    # Check if user exists
    existing = await db.users.find_one({"email": user.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user_id = str(uuid.uuid4())
    user_doc = {
        "id": user_id,
        "email": user.email,
        "password": hash_password(user.password),
        "full_name": user.full_name,
        "phone": user.phone,
        "role": user.role,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.users.insert_one(user_doc)
    
    token = create_access_token({"sub": user_id, "role": user.role})
    
    return TokenResponse(
        access_token=token,
        user=UserResponse(
            id=user_id,
            email=user.email,
            full_name=user.full_name,
            phone=user.phone,
            role=user.role,
            created_at=user_doc["created_at"]
        )
    )

@api_router.post("/auth/login", response_model=TokenResponse)
async def login(credentials: UserLogin):
    user = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user or not verify_password(credentials.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = create_access_token({"sub": user["id"], "role": user["role"]})
    
    return TokenResponse(
        access_token=token,
        user=UserResponse(
            id=user["id"],
            email=user["email"],
            full_name=user["full_name"],
            phone=user["phone"],
            role=user["role"],
            created_at=user["created_at"]
        )
    )

@api_router.post("/auth/admin-login", response_model=TokenResponse)
async def admin_login(credentials: AdminLogin):
    if credentials.password != ADMIN_PASSWORD:
        raise HTTPException(status_code=401, detail="Invalid admin password")
    
    # Create or get admin user
    admin = await db.users.find_one({"role": "admin"}, {"_id": 0})
    if not admin:
        admin_id = str(uuid.uuid4())
        admin = {
            "id": admin_id,
            "email": "admin@freeohns.com",
            "password": hash_password(ADMIN_PASSWORD),
            "full_name": "Admin",
            "phone": "N/A",
            "role": "admin",
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.users.insert_one(admin)
    
    token = create_access_token({"sub": admin["id"], "role": "admin"})
    
    return TokenResponse(
        access_token=token,
        user=UserResponse(
            id=admin["id"],
            email=admin["email"],
            full_name=admin["full_name"],
            phone=admin["phone"],
            role=admin["role"],
            created_at=admin["created_at"]
        )
    )

@api_router.get("/auth/me", response_model=UserResponse)
async def get_me(current_user: dict = Depends(get_current_user)):
    user = await db.users.find_one({"id": current_user["user_id"]}, {"_id": 0, "password": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return UserResponse(**user)

# ===================== SERVICES ROUTES =====================

SERVICES = [
    {
        "id": "taxi",
        "name": "Book Your Ride",
        "slug": "taxi",
        "description": "Reliable, Affordable, Convenient taxi service",
        "icon": "Car",
        "image_url": "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/hhgk9afl_3b8c987f-69cf-4831-9dae-b0613495644f.png",
        "features": ["Easy Booking", "Safe Rides", "24/7 Support"]
    },
    {
        "id": "electro_fix",
        "name": "Electro Fix",
        "slug": "electro-fix",
        "description": "Power Up Your Home - Reliable, Affordable, Safe",
        "icon": "Zap",
        "image_url": "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/z4g9ce4s_71f01b27-ffdb-4d31-ab3c-785fc8e5fb97.jpeg",
        "features": ["Easy Scheduling", "Certified Technicians", "24/7 Support"]
    },
    {
        "id": "cleaning",
        "name": "Book Your Clean",
        "slug": "cleaning",
        "description": "Reliable, Affordable, Thorough cleaning service",
        "icon": "Sparkles",
        "image_url": "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/o851l1ux_12fa3d2a-31fc-4c54-86e7-869f32ef560e.png",
        "features": ["Easy Scheduling", "Thorough Cleaning", "24/7 Support"]
    }
]

@api_router.get("/services", response_model=List[ServiceResponse])
async def get_services():
    return SERVICES

@api_router.get("/services/{service_id}", response_model=ServiceResponse)
async def get_service(service_id: str):
    for service in SERVICES:
        if service["id"] == service_id:
            return service
    raise HTTPException(status_code=404, detail="Service not found")

# ===================== BOOKING ROUTES =====================

@api_router.post("/bookings", response_model=BookingResponse)
async def create_booking(booking: BookingCreate, current_user: dict = Depends(get_current_user)):
    user = await db.users.find_one({"id": current_user["user_id"]}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    booking_id = str(uuid.uuid4())
    booking_doc = {
        "id": booking_id,
        "user_id": current_user["user_id"],
        "user_name": user["full_name"],
        "user_phone": user["phone"],
        "service_type": booking.service_type,
        "status": "pending",
        "pickup_address": booking.pickup_address,
        "dropoff_address": booking.dropoff_address,
        "service_address": booking.service_address,
        "scheduled_date": booking.scheduled_date,
        "scheduled_time": booking.scheduled_time,
        "notes": booking.notes,
        "vehicle_type": booking.vehicle_type,
        "issue_type": booking.issue_type,
        "property_type": booking.property_type,
        "cleaning_type": booking.cleaning_type,
        "provider_id": None,
        "provider_name": None,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.bookings.insert_one(booking_doc)
    return BookingResponse(**booking_doc)

@api_router.get("/bookings", response_model=List[BookingResponse])
async def get_user_bookings(current_user: dict = Depends(get_current_user)):
    bookings = await db.bookings.find(
        {"user_id": current_user["user_id"]},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    return [BookingResponse(**b) for b in bookings]

@api_router.get("/bookings/{booking_id}", response_model=BookingResponse)
async def get_booking(booking_id: str, current_user: dict = Depends(get_current_user)):
    booking = await db.bookings.find_one({"id": booking_id}, {"_id": 0})
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    # Check access
    if current_user["role"] not in ["admin"] and booking["user_id"] != current_user["user_id"]:
        if current_user["role"] in ["driver", "electrician", "cleaner"]:
            if booking.get("provider_id") != current_user["user_id"]:
                raise HTTPException(status_code=403, detail="Access denied")
        else:
            raise HTTPException(status_code=403, detail="Access denied")
    
    return BookingResponse(**booking)

@api_router.patch("/bookings/{booking_id}", response_model=BookingResponse)
async def update_booking(booking_id: str, update: BookingUpdate, current_user: dict = Depends(get_current_user)):
    booking = await db.bookings.find_one({"id": booking_id}, {"_id": 0})
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    update_data = {}
    if update.status:
        update_data["status"] = update.status
    if update.provider_id:
        provider = await db.users.find_one({"id": update.provider_id}, {"_id": 0})
        if provider:
            update_data["provider_id"] = update.provider_id
            update_data["provider_name"] = provider["full_name"]
    
    if update_data:
        await db.bookings.update_one({"id": booking_id}, {"$set": update_data})
        booking.update(update_data)
    
    return BookingResponse(**booking)

@api_router.delete("/bookings/{booking_id}")
async def cancel_booking(booking_id: str, current_user: dict = Depends(get_current_user)):
    booking = await db.bookings.find_one({"id": booking_id}, {"_id": 0})
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    if current_user["role"] != "admin" and booking["user_id"] != current_user["user_id"]:
        raise HTTPException(status_code=403, detail="Access denied")
    
    await db.bookings.update_one({"id": booking_id}, {"$set": {"status": "cancelled"}})
    return {"message": "Booking cancelled"}

# ===================== PROVIDER ROUTES =====================

@api_router.get("/provider/bookings", response_model=List[BookingResponse])
async def get_provider_bookings(current_user: dict = Depends(get_current_user)):
    if current_user["role"] not in ["driver", "electrician", "cleaner"]:
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Get user to determine service type
    user = await db.users.find_one({"id": current_user["user_id"]}, {"_id": 0})
    service_map = {
        "driver": "taxi",
        "electrician": "electro_fix",
        "cleaner": "cleaning"
    }
    service_type = service_map.get(user["role"])
    
    # Get available bookings for this service type or assigned to this provider
    bookings = await db.bookings.find({
        "$or": [
            {"service_type": service_type, "status": "pending", "provider_id": None},
            {"provider_id": current_user["user_id"]}
        ]
    }, {"_id": 0}).sort("created_at", -1).to_list(100)
    
    return [BookingResponse(**b) for b in bookings]

@api_router.post("/provider/accept/{booking_id}", response_model=BookingResponse)
async def accept_booking(booking_id: str, current_user: dict = Depends(get_current_user)):
    if current_user["role"] not in ["driver", "electrician", "cleaner"]:
        raise HTTPException(status_code=403, detail="Access denied")
    
    booking = await db.bookings.find_one({"id": booking_id}, {"_id": 0})
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    if booking["status"] != "pending":
        raise HTTPException(status_code=400, detail="Booking is not available")
    
    provider = await db.users.find_one({"id": current_user["user_id"]}, {"_id": 0})
    
    await db.bookings.update_one(
        {"id": booking_id},
        {"$set": {
            "status": "accepted",
            "provider_id": current_user["user_id"],
            "provider_name": provider["full_name"]
        }}
    )
    
    booking["status"] = "accepted"
    booking["provider_id"] = current_user["user_id"]
    booking["provider_name"] = provider["full_name"]
    
    return BookingResponse(**booking)

@api_router.post("/provider/complete/{booking_id}", response_model=BookingResponse)
async def complete_booking(booking_id: str, current_user: dict = Depends(get_current_user)):
    booking = await db.bookings.find_one({"id": booking_id}, {"_id": 0})
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    if booking["provider_id"] != current_user["user_id"]:
        raise HTTPException(status_code=403, detail="Access denied")
    
(Content truncated due to size limit. Use line ranges to read remaining content)