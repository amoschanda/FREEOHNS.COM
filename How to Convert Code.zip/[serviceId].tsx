import { ScrollView, Text, View, TouchableOpacity, TextInput, ActivityIndicator, Alert } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAuth } from "../context/AuthContext";
import { useEffect, useState } from "react";
import axios from "axios";

const API_URL = process.env.EXPO_PUBLIC_BACKEND_URL ? `${process.env.EXPO_PUBLIC_BACKEND_URL}/api` : 'http://localhost:3000/api';

export default function BookingScreen() {
  const router = useRouter();
  const { serviceId } = useLocalSearchParams();
  const { user, token, loading } = useAuth();
  const [isLoading, setIsLoading] = useState(false);

  // Common fields
  const [address, setAddress] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [notes, setNotes] = useState('');

  // Taxi specific
  const [pickupAddress, setPickupAddress] = useState('');
  const [dropoffAddress, setDropoffAddress] = useState('');
  const [vehicleType, setVehicleType] = useState('economy');

  // Electro fix specific
  const [issueType, setIssueType] = useState('wiring');

  // Cleaning specific
  const [propertyType, setPropertyType] = useState('apartment');
  const [cleaningType, setCleaningType] = useState('standard');

  useEffect(() => {
    if (!loading && !user) {
      router.replace('/(auth)/login');
    }
  }, [user, loading]);

  const handleBooking = async () => {
    if (!scheduledDate || !scheduledTime) {
      Alert.alert('Error', 'Please select date and time');
      return;
    }

    try {
      setIsLoading(true);
      const bookingData: any = {
        service_type: serviceId,
        scheduled_date: scheduledDate,
        scheduled_time: scheduledTime,
        notes,
      };

      if (serviceId === 'taxi') {
        if (!pickupAddress || !dropoffAddress) {
          Alert.alert('Error', 'Please enter pickup and dropoff addresses');
          return;
        }
        bookingData.pickup_address = pickupAddress;
        bookingData.dropoff_address = dropoffAddress;
        bookingData.vehicle_type = vehicleType;
      } else if (serviceId === 'electro_fix') {
        if (!address) {
          Alert.alert('Error', 'Please enter service address');
          return;
        }
        bookingData.service_address = address;
        bookingData.issue_type = issueType;
      } else if (serviceId === 'cleaning') {
        if (!address) {
          Alert.alert('Error', 'Please enter property address');
          return;
        }
        bookingData.service_address = address;
        bookingData.property_type = propertyType;
        bookingData.cleaning_type = cleaningType;
      }

      await axios.post(`${API_URL}/bookings`, bookingData, {
        headers: { Authorization: `Bearer ${token}` },
      });

      Alert.alert('Success', 'Booking created successfully!');
      router.replace('/(tabs)/bookings');
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to create booking');
    } finally {
      setIsLoading(false);
    }
  };

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color="#D4AF37" />
      </ScreenContainer>
    );
  }

  if (!user) {
    return null;
  }

  const getServiceTitle = () => {
    switch (serviceId) {
      case 'taxi':
        return 'Book Your Ride';
      case 'electro_fix':
        return 'Electro Fix';
      case 'cleaning':
        return 'Book Your Clean';
      default:
        return 'Booking';
    }
  };

  return (
    <ScreenContainer className="bg-[#050505]">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-6">
          {/* Header */}
          <View className="gap-2 mt-4">
            <TouchableOpacity onPress={() => router.back()}>
              <Text className="text-base text-[#D4AF37] mb-2">← Back</Text>
            </TouchableOpacity>
            <Text className="text-3xl font-bold text-[#F5F5F5]">
              {getServiceTitle()}
            </Text>
          </View>

          {/* Form */}
          <View className="gap-4">
            {/* Taxi Form */}
            {serviceId === 'taxi' && (
              <>
                <View className="gap-2">
                  <Text className="text-sm font-semibold text-[#F5F5F5]">
                    Pickup Address
                  </Text>
                  <TextInput
                    placeholder="Enter pickup location"
                    placeholderTextColor="#666666"
                    value={pickupAddress}
                    onChangeText={setPickupAddress}
                    editable={!isLoading}
                    className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
                  />
                </View>

                <View className="gap-2">
                  <Text className="text-sm font-semibold text-[#F5F5F5]">
                    Dropoff Address
                  </Text>
                  <TextInput
                    placeholder="Enter dropoff location"
                    placeholderTextColor="#666666"
                    value={dropoffAddress}
                    onChangeText={setDropoffAddress}
                    editable={!isLoading}
                    className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
                  />
                </View>

                <View className="gap-2">
                  <Text className="text-sm font-semibold text-[#F5F5F5]">
                    Vehicle Type
                  </Text>
                  <View className="flex-row gap-2">
                    {['economy', 'comfort', 'premium'].map((type) => (
                      <TouchableOpacity
                        key={type}
                        onPress={() => setVehicleType(type)}
                        activeOpacity={0.7}
                      >
                        <View
                          className={`flex-1 rounded-lg py-3 items-center border ${
                            vehicleType === type
                              ? 'bg-[#D4AF37] border-[#D4AF37]'
                              : 'bg-[#1A1A1A] border-[#262626]'
                          }`}
                        >
                          <Text
                            className={`text-sm font-semibold capitalize ${
                              vehicleType === type ? 'text-[#050505]' : 'text-[#F5F5F5]'
                            }`}
                          >
                            {type}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              </>
            )}

            {/* Electro Fix Form */}
            {serviceId === 'electro_fix' && (
              <>
                <View className="gap-2">
                  <Text className="text-sm font-semibold text-[#F5F5F5]">
                    Service Address
                  </Text>
                  <TextInput
                    placeholder="Enter service address"
                    placeholderTextColor="#666666"
                    value={address}
                    onChangeText={setAddress}
                    editable={!isLoading}
                    className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
                  />
                </View>

                <View className="gap-2">
                  <Text className="text-sm font-semibold text-[#F5F5F5]">
                    Issue Type
                  </Text>
                  <View className="gap-2">
                    {['wiring', 'appliance', 'lighting', 'other'].map((type) => (
                      <TouchableOpacity
                        key={type}
                        onPress={() => setIssueType(type)}
                        activeOpacity={0.7}
                      >
                        <View
                          className={`rounded-lg py-3 px-4 border ${
                            issueType === type
                              ? 'bg-[#D4AF37] border-[#D4AF37]'
                              : 'bg-[#1A1A1A] border-[#262626]'
                          }`}
                        >
                          <Text
                            className={`text-sm font-semibold capitalize ${
                              issueType === type ? 'text-[#050505]' : 'text-[#F5F5F5]'
                            }`}
                          >
                            {type}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              </>
            )}

            {/* Cleaning Form */}
            {serviceId === 'cleaning' && (
              <>
                <View className="gap-2">
                  <Text className="text-sm font-semibold text-[#F5F5F5]">
                    Property Address
                  </Text>
                  <TextInput
                    placeholder="Enter property address"
                    placeholderTextColor="#666666"
                    value={address}
                    onChangeText={setAddress}
                    editable={!isLoading}
                    className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
                  />
                </View>

                <View className="gap-2">
                  <Text className="text-sm font-semibold text-[#F5F5F5]">
                    Property Type
                  </Text>
                  <View className="flex-row gap-2">
                    {['apartment', 'house', 'office'].map((type) => (
                      <TouchableOpacity
                        key={type}
                        onPress={() => setPropertyType(type)}
                        activeOpacity={0.7}
                      >
                        <View
                          className={`flex-1 rounded-lg py-3 items-center border ${
                            propertyType === type
                              ? 'bg-[#D4AF37] border-[#D4AF37]'
                              : 'bg-[#1A1A1A] border-[#262626]'
                          }`}
                        >
                          <Text
                            className={`text-sm font-semibold capitalize ${
                              propertyType === type ? 'text-[#050505]' : 'text-[#F5F5F5]'
                            }`}
                          >
                            {type}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View className="gap-2">
                  <Text className="text-sm font-semibold text-[#F5F5F5]">
                    Cleaning Type
                  </Text>
                  <View className="gap-2">
                    {['standard', 'deep', 'move-in/out'].map((type) => (
                      <TouchableOpacity
                        key={type}
                        onPress={() => setCleaningType(type)}
                        activeOpacity={0.7}
                      >
                        <View
                          className={`rounded-lg py-3 px-4 border ${
                            cleaningType === type
                              ? 'bg-[#D4AF37] border-[#D4AF37]'
                              : 'bg-[#1A1A1A] border-[#262626]'
                          }`}
                        >
                          <Text
                            className={`text-sm font-semibold capitalize ${
                              cleaningType === type ? 'text-[#050505]' : 'text-[#F5F5F5]'
                            }`}
                          >
                            {type}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              </>
            )}

            {/* Common Fields */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-[#F5F5F5]">
                Scheduled Date
              </Text>
              <TextInput
                placeholder="YYYY-MM-DD"
                placeholderTextColor="#666666"
                value={scheduledDate}
                onChangeText={setScheduledDate}
                editable={!isLoading}
                className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
              />
            </View>

            <View className="gap-2">
              <Text className="text-sm font-semibold text-[#F5F5F5]">
                Scheduled Time
              </Text>
              <TextInput
                placeholder="HH:MM"
                placeholderTextColor="#666666"
                value={scheduledTime}
                onChangeText={setScheduledTime}
                editable={!isLoading}
                className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
              />
            </View>

            <View className="gap-2">
              <Text className="text-sm font-semibold text-[#F5F5F5]">
                Additional Notes (Optional)
              </Text>
              <TextInput
                placeholder="Add any special requests..."
                placeholderTextColor="#666666"
                value={notes}
                onChangeText={setNotes}
                editable={!isLoading}
                multiline
                numberOfLines={4}
                className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
              />
            </View>

            {/* Submit Button */}
            <TouchableOpacity
              onPress={handleBooking}
              disabled={isLoading}
              activeOpacity={0.7}
            >
              <View className="bg-[#D4AF37] rounded-lg py-3 items-center mt-4">
                {isLoading ? (
                  <ActivityIndicator color="#050505" />
                ) : (
                  <Text className="text-base font-bold text-[#050505]">
                    Confirm Booking
                  </Text>
                )}
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
