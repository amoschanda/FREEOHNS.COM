import { ScrollView, Text, View, TouchableOpacity, TextInput, ActivityIndicator, Alert } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAuth } from "../context/AuthContext";
import { useEffect, useState } from "react";

export default function RegisterScreen() {
  const router = useRouter();
  const { user, loading, register } = useAuth();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!loading && user) {
      router.replace('/(tabs)');
    }
  }, [user, loading]);

  const handleRegister = async () => {
    if (!fullName || !email || !phone || !password || !confirmPassword) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }

    try {
      setIsLoading(true);
      await register({
        full_name: fullName,
        email,
        phone,
        password,
        role: 'customer',
      });
      router.replace('/(tabs)');
    } catch (error: any) {
      Alert.alert('Registration Failed', error.response?.data?.detail || 'Please try again');
    } finally {
      setIsLoading(false);
    }
  };

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color="#D4AF37" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-[#050505]">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 justify-center gap-6 px-4 py-6">
          {/* Header */}
          <View className="gap-2 mb-4">
            <Text className="text-4xl font-bold text-[#F5F5F5]">
              Create Account
            </Text>
            <Text className="text-base text-[#999999]">
              Join us to book services
            </Text>
          </View>

          {/* Form */}
          <View className="gap-4">
            {/* Full Name Input */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-[#F5F5F5]">
                Full Name
              </Text>
              <TextInput
                placeholder="John Doe"
                placeholderTextColor="#666666"
                value={fullName}
                onChangeText={setFullName}
                editable={!isLoading}
                className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
              />
            </View>

            {/* Email Input */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-[#F5F5F5]">
                Email Address
              </Text>
              <TextInput
                placeholder="you@example.com"
                placeholderTextColor="#666666"
                value={email}
                onChangeText={setEmail}
                editable={!isLoading}
                keyboardType="email-address"
                autoCapitalize="none"
                className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
              />
            </View>

            {/* Phone Input */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-[#F5F5F5]">
                Phone Number
              </Text>
              <TextInput
                placeholder="+1 (555) 000-0000"
                placeholderTextColor="#666666"
                value={phone}
                onChangeText={setPhone}
                editable={!isLoading}
                keyboardType="phone-pad"
                className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
              />
            </View>

            {/* Password Input */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-[#F5F5F5]">
                Password
              </Text>
              <TextInput
                placeholder="••••••••"
                placeholderTextColor="#666666"
                value={password}
                onChangeText={setPassword}
                editable={!isLoading}
                secureTextEntry
                className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
              />
            </View>

            {/* Confirm Password Input */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-[#F5F5F5]">
                Confirm Password
              </Text>
              <TextInput
                placeholder="••••••••"
                placeholderTextColor="#666666"
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                editable={!isLoading}
                secureTextEntry
                className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
              />
            </View>

            {/* Register Button */}
            <TouchableOpacity
              onPress={handleRegister}
              disabled={isLoading}
              activeOpacity={0.7}
            >
              <View className="bg-[#D4AF37] rounded-lg py-3 items-center">
                {isLoading ? (
                  <ActivityIndicator color="#050505" />
                ) : (
                  <Text className="text-base font-bold text-[#050505]">
                    Create Account
                  </Text>
                )}
              </View>
            </TouchableOpacity>
          </View>

          {/* Login Link */}
          <View className="flex-row items-center justify-center gap-2">
            <Text className="text-base text-[#999999]">
              Already have an account?
            </Text>
            <TouchableOpacity
              onPress={() => router.replace('/(auth)/login')}
              disabled={isLoading}
            >
              <Text className="text-base font-bold text-[#D4AF37]">
                Sign In
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
