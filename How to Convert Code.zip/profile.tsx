import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAuth } from "../context/AuthContext";
import { useEffect } from "react";

export default function ProfileScreen() {
  const router = useRouter();
  const { user, loading, logout } = useAuth();

  useEffect(() => {
    if (!loading && !user) {
      router.replace('/(auth)/login');
    }
  }, [user, loading]);

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color="#D4AF37" />
      </ScreenContainer>
    );
  }

  if (!user) {
    return null;
  }

  const handleLogout = async () => {
    await logout();
    router.replace('/(auth)/login');
  };

  return (
    <ScreenContainer className="bg-[#050505]">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-6">
          {/* Header */}
          <View className="gap-2 mt-4">
            <Text className="text-3xl font-bold text-[#F5F5F5]">
              My Profile
            </Text>
          </View>

          {/* Profile Card */}
          <View className="bg-[#1A1A1A] rounded-2xl p-6 border border-[#262626]">
            <View className="items-center mb-6">
              <View className="w-20 h-20 rounded-full bg-[#D4AF37] items-center justify-center mb-4">
                <Text className="text-4xl">👤</Text>
              </View>
              <Text className="text-2xl font-bold text-[#F5F5F5]">
                {user.full_name}
              </Text>
              <Text className="text-sm text-[#D4AF37] capitalize mt-1">
                {user.role}
              </Text>
            </View>

            {/* Info Section */}
            <View className="gap-4">
              <View className="border-t border-[#262626] pt-4">
                <Text className="text-xs text-[#999999] uppercase tracking-wider mb-2">
                  Email
                </Text>
                <Text className="text-base text-[#F5F5F5]">
                  {user.email}
                </Text>
              </View>

              <View className="border-t border-[#262626] pt-4">
                <Text className="text-xs text-[#999999] uppercase tracking-wider mb-2">
                  Phone
                </Text>
                <Text className="text-base text-[#F5F5F5]">
                  {user.phone}
                </Text>
              </View>

              <View className="border-t border-[#262626] pt-4">
                <Text className="text-xs text-[#999999] uppercase tracking-wider mb-2">
                  Member Since
                </Text>
                <Text className="text-base text-[#F5F5F5]">
                  {new Date(user.created_at).toLocaleDateString()}
                </Text>
              </View>
            </View>
          </View>

          {/* Action Buttons */}
          <View className="gap-3">
            <TouchableOpacity
              onPress={() => {}}
              activeOpacity={0.7}
            >
              <View className="bg-[#1A1A1A] rounded-xl p-4 border border-[#262626]">
                <Text className="text-base font-semibold text-[#F5F5F5]">
                  ✏️ Edit Profile
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => {}}
              activeOpacity={0.7}
            >
              <View className="bg-[#1A1A1A] rounded-xl p-4 border border-[#262626]">
                <Text className="text-base font-semibold text-[#F5F5F5]">
                  🔐 Change Password
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleLogout}
              activeOpacity={0.7}
            >
              <View className="bg-[#EF4444]/10 rounded-xl p-4 border border-[#EF4444]">
                <Text className="text-base font-semibold text-[#EF4444] text-center">
                  🚪 Logout
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
