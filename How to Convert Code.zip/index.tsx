import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAuth } from "../context/AuthContext";
import { useEffect } from "react";

const SERVICES = [
  {
    id: 'taxi',
    name: 'Book Your Ride',
    description: 'Reliable, Affordable, Convenient',
    icon: '🚗',
    features: ['Easy Booking', 'Safe Rides', '24/7 Support'],
  },
  {
    id: 'electro_fix',
    name: 'Electro Fix',
    description: 'Power Up Your Home',
    icon: '⚡',
    features: ['Easy Scheduling', 'Certified Technicians', '24/7 Support'],
  },
  {
    id: 'cleaning',
    name: 'Book Your Clean',
    description: 'Reliable, Affordable, Thorough',
    icon: '✨',
    features: ['Easy Scheduling', 'Thorough Cleaning', '24/7 Support'],
  }
];

export default function HomeScreen() {
  const router = useRouter();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && !user) {
      router.replace('/login');
    }
  }, [user, loading]);

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color="#D4AF37" />
      </ScreenContainer>
    );
  }

  if (!user) {
    return null;
  }

  const handleServicePress = (serviceId: string) => {
    router.push(`/booking/${serviceId}`);
  };

  return (
    <ScreenContainer className="bg-[#050505]">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-6">
          {/* Header */}
          <View className="gap-2 mt-4">
            <Text className="text-3xl font-bold text-[#F5F5F5]">
              Welcome, {user.full_name.split(' ')[0]}
            </Text>
            <Text className="text-base text-[#999999]">
              What service do you need today?
            </Text>
          </View>

          {/* Service Cards */}
          <View className="gap-4">
            {SERVICES.map((service) => (
              <TouchableOpacity
                key={service.id}
                onPress={() => handleServicePress(service.id)}
                activeOpacity={0.7}
              >
                <View className="bg-[#1A1A1A] rounded-2xl p-6 border border-[#262626]">
                  <View className="flex-row items-start justify-between mb-4">
                    <View className="flex-1">
                      <Text className="text-2xl mb-2">{service.icon}</Text>
                      <Text className="text-xl font-bold text-[#F5F5F5] mb-1">
                        {service.name}
                      </Text>
                      <Text className="text-sm text-[#999999]">
                        {service.description}
                      </Text>
                    </View>
                    <Text className="text-2xl">→</Text>
                  </View>

                  {/* Features */}
                  <View className="flex-row flex-wrap gap-2">
                    {service.features.map((feature, idx) => (
                      <View
                        key={idx}
                        className="bg-[#262626] rounded-full px-3 py-1"
                      >
                        <Text className="text-xs text-[#D4AF37]">
                          {feature}
                        </Text>
                      </View>
                    ))}
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* Quick Actions */}
          <View className="gap-3 mt-4">
            <TouchableOpacity
              onPress={() => router.push('/(tabs)/bookings')}
              activeOpacity={0.7}
            >
              <View className="bg-[#1A1A1A] rounded-xl p-4 border border-[#262626]">
                <Text className="text-base font-semibold text-[#F5F5F5]">
                  📋 View My Bookings
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => router.push('/(tabs)/profile')}
              activeOpacity={0.7}
            >
              <View className="bg-[#1A1A1A] rounded-xl p-4 border border-[#262626]">
                <Text className="text-base font-semibold text-[#F5F5F5]">
                  👤 My Profile
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
