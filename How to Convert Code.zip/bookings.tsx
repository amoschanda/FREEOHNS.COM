import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAuth } from "../context/AuthContext";
import { useEffect, useState } from "react";
import axios from "axios";

interface Booking {
  id: string;
  service_type: string;
  status: string;
  scheduled_date: string;
  scheduled_time: string;
  provider_name?: string;
  pickup_address?: string;
  service_address?: string;
}

const API_URL = process.env.EXPO_PUBLIC_BACKEND_URL ? `${process.env.EXPO_PUBLIC_BACKEND_URL}/api` : 'http://localhost:3000/api';

export default function BookingsScreen() {
  const router = useRouter();
  const { user, token, loading } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loadingBookings, setLoadingBookings] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      router.replace('/(auth)/login');
    }
  }, [user, loading]);

  useEffect(() => {
    if (user && token) {
      fetchBookings();
    }
  }, [user, token]);

  const fetchBookings = async () => {
    try {
      setLoadingBookings(true);
      const response = await axios.get(`${API_URL}/bookings`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setBookings(response.data);
    } catch (error) {
      console.error('Failed to fetch bookings:', error);
    } finally {
      setLoadingBookings(false);
    }
  };

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color="#D4AF37" />
      </ScreenContainer>
    );
  }

  if (!user) {
    return null;
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return '#F59E0B';
      case 'accepted':
        return '#3B82F6';
      case 'completed':
        return '#4ADE80';
      case 'cancelled':
        return '#EF4444';
      default:
        return '#999999';
    }
  };

  const getServiceIcon = (serviceType: string) => {
    switch (serviceType) {
      case 'taxi':
        return '🚗';
      case 'electro_fix':
        return '⚡';
      case 'cleaning':
        return '✨';
      default:
        return '📋';
    }
  };

  return (
    <ScreenContainer className="bg-[#050505]">
      <View className="gap-4 pb-6">
        <View className="gap-2 mt-4">
          <Text className="text-3xl font-bold text-[#F5F5F5]">
            My Bookings
          </Text>
          <Text className="text-base text-[#999999]">
            {bookings.length} booking{bookings.length !== 1 ? 's' : ''}
          </Text>
        </View>

        {loadingBookings ? (
          <View className="items-center justify-center py-8">
            <ActivityIndicator size="large" color="#D4AF37" />
          </View>
        ) : bookings.length === 0 ? (
          <View className="items-center justify-center py-8">
            <Text className="text-[#999999] text-base">
              No bookings yet. Start by booking a service!
            </Text>
          </View>
        ) : (
          <FlatList
            data={bookings}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            renderItem={({ item }) => (
              <View className="bg-[#1A1A1A] rounded-2xl p-4 border border-[#262626] mb-4">
                <View className="flex-row items-start justify-between mb-3">
                  <View className="flex-1">
                    <View className="flex-row items-center gap-2 mb-2">
                      <Text className="text-2xl">{getServiceIcon(item.service_type)}</Text>
                      <Text className="text-lg font-bold text-[#F5F5F5] capitalize">
                        {item.service_type.replace('_', ' ')}
                      </Text>
                    </View>
                    <Text className="text-sm text-[#999999]">
                      {item.scheduled_date} at {item.scheduled_time}
                    </Text>
                  </View>
                  <View
                    className="rounded-full px-3 py-1"
                    style={{ backgroundColor: getStatusColor(item.status) + '20' }}
                  >
                    <Text
                      className="text-xs font-semibold capitalize"
                      style={{ color: getStatusColor(item.status) }}
                    >
                      {item.status}
                    </Text>
                  </View>
                </View>

                {item.provider_name && (
                  <Text className="text-sm text-[#D4AF37] mb-2">
                    Provider: {item.provider_name}
                  </Text>
                )}

                {(item.pickup_address || item.service_address) && (
                  <Text className="text-sm text-[#999999] mb-3">
                    📍 {item.pickup_address || item.service_address}
                  </Text>
                )}

                <TouchableOpacity
                  activeOpacity={0.7}
                  className="bg-[#262626] rounded-lg p-3"
                >
                  <Text className="text-center text-sm font-semibold text-[#D4AF37]">
                    View Details
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          />
        )}
      </View>
    </ScreenContainer>
  );
}
