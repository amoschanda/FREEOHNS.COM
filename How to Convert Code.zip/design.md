# FREEOHNS Mobile App - Design Document

## Overview
FREEOHNS is a multi-role service booking platform for taxi, electrical repair, and cleaning services. The mobile app serves three user types: customers, service providers, and administrators.

## Screen List

### Authentication Screens
1. **Landing Page** - Welcome screen with role selection (Customer, Provider, Admin)
2. **Customer Login** - Email/password login for customers
3. **Customer Register** - Sign up form for new customers
4. **Provider Login** - Email/password login for service providers
5. **Admin Login** - Password-only login for administrators

### Customer Screens
6. **Customer Dashboard** - Browse available services (Taxi, Electro Fix, Cleaning)
7. **Service Detail** - Service information and booking button
8. **Booking Form** - Create new booking with service-specific fields
9. **Booking History** - View past and current bookings
10. **Profile** - User profile and account settings

### Provider Screens
11. **Provider Dashboard** - View assigned bookings and job queue
12. **Booking Details** - Accept/reject/complete bookings

### Admin Screens
13. **Admin Dashboard** - System overview, user management, analytics

## Primary Content and Functionality

### Landing Page
- Hero section with app branding
- Three role selection buttons: Customer, Provider, Admin
- Navigation to respective login pages

### Customer Dashboard
- Service cards (Taxi, Electro Fix, Cleaning) with icons and descriptions
- Each card shows service name, description, and features
- Tap card to navigate to booking form
- Bottom tab bar: Home, Bookings, Profile

### Booking Form (Service-Specific)
**Taxi Booking:**
- Pickup address (text input)
- Dropoff address (text input)
- Scheduled date (date picker)
- Scheduled time (time picker)
- Vehicle type selector (economy, comfort, premium)
- Additional notes (optional)

**Electro Fix Booking:**
- Service address (text input)
- Issue type selector (wiring, appliance, lighting, other)
- Scheduled date (date picker)
- Scheduled time (time picker)
- Additional notes (optional)

**Cleaning Booking:**
- Property address (text input)
- Property type selector (apartment, house, office)
- Cleaning type selector (standard, deep, move-in/out)
- Scheduled date (date picker)
- Scheduled time (time picker)
- Additional notes (optional)

### Booking History
- List of all bookings with status badges (pending, accepted, completed, cancelled)
- Each booking shows service type, date, time, and provider name (if assigned)
- Tap to view full booking details
- Pull-to-refresh functionality

### Profile Screen
- User information (name, email, phone)
- Edit profile button
- Logout button

### Provider Dashboard
- List of assigned bookings with status
- Booking cards show customer name, service type, date/time, location
- Accept/reject buttons for pending bookings
- Mark as completed for accepted bookings

### Admin Dashboard
- System statistics (total users, bookings, revenue)
- User management section
- Recent bookings overview

## Key User Flows

### Customer Booking Flow
1. User lands on Landing Page
2. Selects "Customer" role
3. Logs in or registers
4. Navigates to Customer Dashboard
5. Browses service cards
6. Taps a service card
7. Fills out service-specific booking form
8. Submits booking
9. Redirected to Booking History
10. Can view booking status and provider assignment

### Provider Work Flow
1. User lands on Landing Page
2. Selects "Provider" role
3. Logs in
4. Navigates to Provider Dashboard
5. Views list of pending bookings
6. Accepts or rejects bookings
7. Once accepted, marks as completed when service is done
8. Updates booking status

### Admin Access Flow
1. User lands on Landing Page
2. Selects "Admin" role
3. Enters admin password
4. Accesses Admin Dashboard
5. Views system statistics and user management

## Color Choices

The app uses a dark, premium theme with gold accents:

| Element | Color | Hex |
|---------|-------|-----|
| Primary Accent | Gold | #D4AF37 |
| Background | Dark Black | #050505 |
| Surface | Dark Gray | #1A1A1A |
| Text Primary | Off White | #F5F5F5 |
| Text Secondary | Gray | #999999 |
| Border | Dark Gray | #262626 |
| Success | Green | #4ADE80 |
| Warning | Orange | #F59E0B |
| Error | Red | #EF4444 |

## Layout Principles

- **Portrait orientation** (9:16) optimized for one-handed usage
- **Bottom tab bar** for main navigation (Customer only)
- **Safe area handling** for notch and home indicator
- **Responsive spacing** with consistent padding (16px base unit)
- **Card-based layouts** for service and booking displays
- **Clear visual hierarchy** with typography and color contrast
- **Touch-friendly** buttons and interactive elements (min 48px tap target)

## Navigation Structure

```
Landing Page
├── Customer Path
│   ├── Login/Register
│   └── Customer Dashboard (Tab)
│       ├── Home (Service Cards)
│       ├── Bookings (History)
│       └── Profile
├── Provider Path
│   ├── Provider Login
│   └── Provider Dashboard
└── Admin Path
    ├── Admin Login
    └── Admin Dashboard
```

## Technical Notes

- Uses Expo Router for navigation
- NativeWind (Tailwind CSS) for styling
- Axios for API calls to FastAPI backend
- JWT token-based authentication
- Local AsyncStorage for token persistence
- MongoDB backend for data persistence
