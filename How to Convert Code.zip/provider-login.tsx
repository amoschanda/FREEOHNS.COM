import { ScrollView, Text, View, TouchableOpacity, TextInput, ActivityIndicator, Alert } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAuth } from "../context/AuthContext";
import { useEffect, useState } from "react";

export default function ProviderLoginScreen() {
  const router = useRouter();
  const { user, loading, login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!loading && user) {
      router.replace('/(tabs)');
    }
  }, [user, loading]);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    try {
      setIsLoading(true);
      await login(email, password);
      router.replace('/(tabs)');
    } catch (error: any) {
      Alert.alert('Login Failed', error.response?.data?.detail || 'Invalid credentials');
    } finally {
      setIsLoading(false);
    }
  };

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color="#D4AF37" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-[#050505]">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 justify-center gap-6 px-4">
          {/* Header */}
          <View className="gap-2 mb-4">
            <Text className="text-4xl font-bold text-[#F5F5F5]">
              Provider Login
            </Text>
            <Text className="text-base text-[#999999]">
              Sign in to manage your services
            </Text>
          </View>

          {/* Form */}
          <View className="gap-4">
            {/* Email Input */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-[#F5F5F5]">
                Email Address
              </Text>
              <TextInput
                placeholder="provider@example.com"
                placeholderTextColor="#666666"
                value={email}
                onChangeText={setEmail}
                editable={!isLoading}
                keyboardType="email-address"
                autoCapitalize="none"
                className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
              />
            </View>

            {/* Password Input */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-[#F5F5F5]">
                Password
              </Text>
              <TextInput
                placeholder="••••••••"
                placeholderTextColor="#666666"
                value={password}
                onChangeText={setPassword}
                editable={!isLoading}
                secureTextEntry
                className="bg-[#1A1A1A] border border-[#262626] rounded-lg px-4 py-3 text-[#F5F5F5]"
              />
            </View>

            {/* Login Button */}
            <TouchableOpacity
              onPress={handleLogin}
              disabled={isLoading}
              activeOpacity={0.7}
            >
              <View className="bg-[#D4AF37] rounded-lg py-3 items-center">
                {isLoading ? (
                  <ActivityIndicator color="#050505" />
                ) : (
                  <Text className="text-base font-bold text-[#050505]">
                    Sign In
                  </Text>
                )}
              </View>
            </TouchableOpacity>
          </View>

          {/* Divider */}
          <View className="flex-row items-center gap-3">
            <View className="flex-1 h-px bg-[#262626]" />
            <Text className="text-sm text-[#999999]">or</Text>
            <View className="flex-1 h-px bg-[#262626]" />
          </View>

          {/* Other Login Options */}
          <View className="gap-3">
            <TouchableOpacity
              onPress={() => router.replace('/(auth)/login')}
              disabled={isLoading}
              activeOpacity={0.7}
            >
              <View className="bg-[#1A1A1A] border border-[#262626] rounded-lg py-3 items-center">
                <Text className="text-base font-semibold text-[#F5F5F5]">
                  Customer Login
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => router.replace('/(auth)/admin-login')}
              disabled={isLoading}
              activeOpacity={0.7}
            >
              <View className="bg-[#1A1A1A] border border-[#262626] rounded-lg py-3 items-center">
                <Text className="text-base font-semibold text-[#F5F5F5]">
                  Admin Login
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
