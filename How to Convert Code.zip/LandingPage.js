import { Car, Zap, Sparkles, Phone, Shield, Clock, ChevronRight } from 'lucide-react';
import { Button } from '../components/ui/button';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";

const services = [
  {
    id: 'taxi',
    name: 'Book Your Ride',
    description: 'Reliable, Affordable, Convenient',
    icon: Car,
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/hhgk9afl_3b8c987f-69cf-4831-9dae-b0613495644f.png',
    features: ['Easy Booking', 'Safe Rides', '24/7 Support'],
    accent: 'gold'
  },
  {
    id: 'electro_fix',
    name: 'Electro Fix',
    description: 'Power Up Your Home',
    icon: Zap,
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/z4g9ce4s_71f01b27-ffdb-4d31-ab3c-785fc8e5fb97.jpeg',
    features: ['Easy Scheduling', 'Certified Technicians', '24/7 Support'],
    accent: 'cyan'
  },
  {
    id: 'cleaning',
    name: 'Book Your Clean',
    description: 'Reliable, Affordable, Thorough',
    icon: Sparkles,
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/o851l1ux_12fa3d2a-31fc-4c54-86e7-869f32ef560e.png',
    features: ['Easy Scheduling', 'Thorough Cleaning', '24/7 Support'],
    accent: 'gold'
  }
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#050505]">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#050505]/80 backdrop-blur-xl border-b border-[#262626]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <img src={LOGO_URL} alt="FREEOHNS" className="h-10 w-auto" />
              <span className="text-xl font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                FREEOHNS
              </span>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/provider-login">
                <Button variant="ghost" className="text-[#A3A3A3] hover:text-white hover:bg-white/5" data-testid="provider-login-btn">
                  Provider Login
                </Button>
              </Link>
              <Link to="/admin-login">
                <Button variant="ghost" className="text-[#A3A3A3] hover:text-white hover:bg-white/5" data-testid="admin-login-btn">
                  Admin
                </Button>
              </Link>
              <Link to="/login">
                <Button variant="outline" className="border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37]/10 rounded-full px-6" data-testid="login-btn">
                  Sign In
                </Button>
              </Link>
              <Link to="/register">
                <Button className="bg-[#D4AF37] text-black hover:bg-[#F4C430] rounded-full px-6 font-semibold" data-testid="register-btn">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 stagger-children">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>