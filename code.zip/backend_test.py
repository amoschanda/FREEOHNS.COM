#!/usr/bin/env python3
"""
FREEOHNS Backend API Testing Suite
Tests all endpoints for the taxi app with 3 services: taxi, electro_fix, cleaning
"""

import requests
import sys
import json
from datetime import datetime, timedelta

class FreeohnsAPITester:
    def __init__(self, base_url="https://freeohns-cab.preview.emergentagent.com/api"):
        self.base_url = base_url
        self.customer_token = None
        self.provider_token = None
        self.admin_token = None
        self.test_user_id = None
        self.test_provider_id = None
        self.test_booking_id = None
        self.tests_run = 0
        self.tests_passed = 0
        self.failed_tests = []

    def log_test(self, name, success, details=""):
        """Log test results"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name}")
        else:
            print(f"❌ {name} - {details}")
            self.failed_tests.append(f"{name}: {details}")

    def make_request(self, method, endpoint, data=None, token=None, expected_status=200):
        """Make HTTP request with error handling"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}
        if token:
            headers['Authorization'] = f'Bearer {token}'

        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=10)
            elif method == 'PATCH':
                response = requests.patch(url, json=data, headers=headers, timeout=10)
            elif method == 'DELETE':
                response = requests.delete(url, headers=headers, timeout=10)
            else:
                return False, f"Unsupported method: {method}"

            success = response.status_code == expected_status
            if success:
                try:
                    return True, response.json()
                except:
                    return True, {"message": "Success"}
            else:
                try:
                    error_detail = response.json().get('detail', f'Status {response.status_code}')
                except:
                    error_detail = f'Status {response.status_code}'
                return False, error_detail

        except requests.exceptions.RequestException as e:
            return False, f"Request failed: {str(e)}"

    def test_root_endpoint(self):
        """Test root API endpoint"""
        success, response = self.make_request('GET', '')
        self.log_test("Root endpoint", success, "" if success else response)
        return success

    def test_services_endpoint(self):
        """Test services listing"""
        success, response = self.make_request('GET', 'services')
        if success:
            services = response
            expected_services = ['taxi', 'electro_fix', 'cleaning']
            service_ids = [s['id'] for s in services]
            all_services_present = all(sid in service_ids for sid in expected_services)
            self.log_test("Services endpoint", all_services_present, 
                         f"Expected {expected_services}, got {service_ids}" if not all_services_present else "")
            return all_services_present
        else:
            self.log_test("Services endpoint", False, response)
            return False

    def test_customer_registration(self):
        """Test customer registration"""
        timestamp = datetime.now().strftime("%H%M%S")
        test_data = {
            "full_name": f"Test Customer {timestamp}",
            "email": f"customer{timestamp}@test.com",
            "phone": f"+1234567{timestamp[-4:]}",
            "password": "testpass123",
            "role": "customer"
        }
        
        success, response = self.make_request('POST', 'auth/register', test_data, expected_status=200)
        if success:
            self.customer_token = response.get('access_token')
            self.test_user_id = response.get('user', {}).get('id')
            self.log_test("Customer registration", True)
            return True
        else:
            self.log_test("Customer registration", False, response)
            return False

    def test_provider_registration(self):
        """Test provider registration (driver)"""
        timestamp = datetime.now().strftime("%H%M%S")
        test_data = {
            "full_name": f"Test Driver {timestamp}",
            "email": f"driver{timestamp}@test.com",
            "phone": f"+1234568{timestamp[-4:]}",
            "password": "testpass123",
            "role": "driver"
        }
        
        success, response = self.make_request('POST', 'auth/register', test_data, expected_status=200)
        if success:
            self.provider_token = response.get('access_token')
            self.test_provider_id = response.get('user', {}).get('id')
            self.log_test("Provider registration", True)
            return True
        else:
            self.log_test("Provider registration", False, response)
            return False

    def test_admin_login(self):
        """Test admin login with password 'Johnson'"""
        test_data = {"password": "Johnson"}
        
        success, response = self.make_request('POST', 'auth/admin-login', test_data, expected_status=200)
        if success:
            self.admin_token = response.get('access_token')
            admin_user = response.get('user', {})
            is_admin = admin_user.get('role') == 'admin'
            self.log_test("Admin login", is_admin, "" if is_admin else f"Expected admin role, got {admin_user.get('role')}")
            return is_admin
        else:
            self.log_test("Admin login", False, response)
            return False

    def test_customer_login(self):
        """Test customer login"""
        timestamp = datetime.now().strftime("%H%M%S")
        login_data = {
            "email": f"customer{timestamp}@test.com",
            "password": "testpass123"
        }
        
        success, response = self.make_request('POST', 'auth/login', login_data, expected_status=200)
        self.log_test("Customer login", success, "" if success else response)
        return success

    def test_auth_me_endpoint(self):
        """Test /auth/me endpoint with customer token"""
        if not self.customer_token:
            self.log_test("Auth me endpoint", False, "No customer token available")
            return False
            
        success, response = self.make_request('GET', 'auth/me', token=self.customer_token)
        if success:
            user_data = response
            has_required_fields = all(field in user_data for field in ['id', 'email', 'full_name', 'role'])
            self.log_test("Auth me endpoint", has_required_fields, 
                         f"Missing fields in response: {user_data}" if not has_required_fields else "")
            return has_required_fields
        else:
            self.log_test("Auth me endpoint", False, response)
            return False

    def test_create_taxi_booking(self):
        """Test creating a taxi booking"""
        if not self.customer_token:
            self.log_test("Create taxi booking", False, "No customer token available")
            return False

        tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        booking_data = {
            "service_type": "taxi",
            "pickup_address": "123 Main St, City",
            "dropoff_address": "456 Oak Ave, City",
            "scheduled_date": tomorrow,
            "scheduled_time": "10:00 AM",
            "vehicle_type": "Sedan",
            "notes": "Test taxi booking"
        }
        
        success, response = self.make_request('POST', 'bookings', booking_data, 
                                            token=self.customer_token, expected_status=200)
        if success:
            self.test_booking_id = response.get('id')
            self.log_test("Create taxi booking", True)
            return True
        else:
            self.log_test("Create taxi booking", False, response)
            return False

    def test_create_electro_booking(self):
        """Test creating an electro fix booking"""
        if not self.customer_token:
            self.log_test("Create electro booking", False, "No customer token available")
            return False

        tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        booking_data = {
            "service_type": "electro_fix",
            "service_address": "789 Electric St, City",
            "scheduled_date": tomorrow,
            "scheduled_time": "02:00 PM",
            "issue_type": "Wiring Issues",
            "notes": "Test electrical service booking"
        }
        
        success, response = self.make_request('POST', 'bookings', booking_data, 
                                            token=self.customer_token, expected_status=200)
        self.log_test("Create electro booking", success, "" if success else response)
        return success

    def test_create_cleaning_booking(self):
        """Test creating a cleaning booking"""
        if not self.customer_token:
            self.log_test("Create cleaning booking", False, "No customer token available")
            return False

        tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        booking_data = {
            "service_type": "cleaning",
            "service_address": "321 Clean Ave, City",
            "scheduled_date": tomorrow,
            "scheduled_time": "11:00 AM",
            "property_type": "House",
            "cleaning_type": "Deep Cleaning",
            "notes": "Test cleaning service booking"
        }
        
        success, response = self.make_request('POST', 'bookings', booking_data, 
                                            token=self.customer_token, expected_status=200)
        self.log_test("Create cleaning booking", success, "" if success else response)
        return success

    def test_get_user_bookings(self):
        """Test getting user's bookings"""
        if not self.customer_token:
            self.log_test("Get user bookings", False, "No customer token available")
            return False
            
        success, response = self.make_request('GET', 'bookings', token=self.customer_token)
        if success:
            bookings = response
            has_bookings = len(bookings) > 0
            self.log_test("Get user bookings", has_bookings, 
                         f"Expected bookings, got {len(bookings)}" if not has_bookings else "")
            return has_bookings
        else:
            self.log_test("Get user bookings", False, response)
            return False

    def test_provider_get_bookings(self):
        """Test provider getting available bookings"""
        if not self.provider_token:
            self.log_test("Provider get bookings", False, "No provider token available")
            return False
            
        success, response = self.make_request('GET', 'provider/bookings', token=self.provider_token)
        self.log_test("Provider get bookings", success, "" if success else response)
        return success

    def test_provider_accept_booking(self):
        """Test provider accepting a booking"""
        if not self.provider_token or not self.test_booking_id:
            self.log_test("Provider accept booking", False, "No provider token or booking ID available")
            return False
            
        success, response = self.make_request('POST', f'provider/accept/{self.test_booking_id}', 
                                            token=self.provider_token, expected_status=200)
        self.log_test("Provider accept booking", success, "" if success else response)
        return success

    def test_provider_complete_booking(self):
        """Test provider completing a booking"""
        if not self.provider_token or not self.test_booking_id:
            self.log_test("Provider complete booking", False, "No provider token or booking ID available")
            return False
            
        success, response = self.make_request('POST', f'provider/complete/{self.test_booking_id}', 
                                            token=self.provider_token, expected_status=200)
        self.log_test("Provider complete booking", success, "" if success else response)
        return success

    def test_admin_get_stats(self):
        """Test admin getting stats"""
        if not self.admin_token:
            self.log_test("Admin get stats", False, "No admin token available")
            return False
            
        success, response = self.make_request('GET', 'admin/stats', token=self.admin_token)
        if success:
            stats = response
            required_fields = ['total_bookings', 'total_users', 'total_providers', 'service_breakdown']
            has_required_fields = all(field in stats for field in required_fields)
            self.log_test("Admin get stats", has_required_fields, 
                         f"Missing fields: {[f for f in required_fields if f not in stats]}" if not has_required_fields else "")
            return has_required_fields
        else:
            self.log_test("Admin get stats", False, response)
            return False

    def test_admin_get_bookings(self):
        """Test admin getting all bookings"""
        if not self.admin_token:
            self.log_test("Admin get bookings", False, "No admin token available")
            return False
            
        success, response = self.make_request('GET', 'admin/bookings', token=self.admin_token)
        self.log_test("Admin get bookings", success, "" if success else response)
        return success

    def test_admin_get_users(self):
        """Test admin getting all users"""
        if not self.admin_token:
            self.log_test("Admin get users", False, "No admin token available")
            return False
            
        success, response = self.make_request('GET', 'admin/users', token=self.admin_token)
        self.log_test("Admin get users", success, "" if success else response)
        return success

    def test_admin_get_providers(self):
        """Test admin getting all providers"""
        if not self.admin_token:
            self.log_test("Admin get providers", False, "No admin token available")
            return False
            
        success, response = self.make_request('GET', 'admin/providers', token=self.admin_token)
        self.log_test("Admin get providers", success, "" if success else response)
        return success

    def run_all_tests(self):
        """Run all backend tests"""
        print("🚀 Starting FREEOHNS Backend API Tests")
        print(f"📍 Testing API at: {self.base_url}")
        print("=" * 60)

        # Basic API tests
        print("\n📋 Basic API Tests:")
        self.test_root_endpoint()
        self.test_services_endpoint()

        # Authentication tests
        print("\n🔐 Authentication Tests:")
        self.test_customer_registration()
        self.test_provider_registration()
        self.test_admin_login()
        self.test_customer_login()
        self.test_auth_me_endpoint()

        # Booking tests
        print("\n📅 Booking Tests:")
        self.test_create_taxi_booking()
        self.test_create_electro_booking()
        self.test_create_cleaning_booking()
        self.test_get_user_bookings()

        # Provider tests
        print("\n🚗 Provider Tests:")
        self.test_provider_get_bookings()
        self.test_provider_accept_booking()
        self.test_provider_complete_booking()

        # Admin tests
        print("\n👑 Admin Tests:")
        self.test_admin_get_stats()
        self.test_admin_get_bookings()
        self.test_admin_get_users()
        self.test_admin_get_providers()

        # Results
        print("\n" + "=" * 60)
        print(f"📊 Test Results: {self.tests_passed}/{self.tests_run} passed")
        
        if self.failed_tests:
            print(f"\n❌ Failed Tests ({len(self.failed_tests)}):")
            for failure in self.failed_tests:
                print(f"  • {failure}")
        else:
            print("\n🎉 All tests passed!")

        return self.tests_passed == self.tests_run

def main():
    """Main test runner"""
    tester = FreeohnsAPITester()
    success = tester.run_all_tests()
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())