import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "./components/ui/sonner";
import { AuthProvider, useAuth } from "./context/AuthContext";

// Pages
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import ProviderLoginPage from "./pages/ProviderLoginPage";
import AdminLoginPage from "./pages/AdminLoginPage";
import CustomerDashboard from "./pages/CustomerDashboard";
import BookingPage from "./pages/BookingPage";
import BookingHistoryPage from "./pages/BookingHistoryPage";
import ProfilePage from "./pages/ProfilePage";
import ProviderDashboard from "./pages/ProviderDashboard";
import AdminDashboard from "./pages/AdminDashboard";

// Protected Route Component
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    // Redirect based on role
    if (user.role === "admin") return <Navigate to="/admin" replace />;
    if (["driver", "electrician", "cleaner"].includes(user.role)) return <Navigate to="/provider" replace />;
    return <Navigate to="/dashboard" replace />;
  }
  
  return children;
};

function AppRoutes() {
  const { user } = useAuth();

  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={user ? <Navigate to="/dashboard" replace /> : <LandingPage />} />
      <Route path="/login" element={user ? <Navigate to="/dashboard" replace /> : <LoginPage />} />
      <Route path="/register" element={user ? <Navigate to="/dashboard" replace /> : <RegisterPage />} />
      <Route path="/provider-login" element={user ? <Navigate to="/provider" replace /> : <ProviderLoginPage />} />
      <Route path="/admin-login" element={user?.role === "admin" ? <Navigate to="/admin" replace /> : <AdminLoginPage />} />
      
      {/* Customer routes */}
      <Route path="/dashboard" element={
        <ProtectedRoute allowedRoles={["customer"]}>
          <CustomerDashboard />
        </ProtectedRoute>
      } />
      <Route path="/book/:serviceId" element={
        <ProtectedRoute allowedRoles={["customer"]}>
          <BookingPage />
        </ProtectedRoute>
      } />
      <Route path="/bookings" element={
        <ProtectedRoute allowedRoles={["customer"]}>
          <BookingHistoryPage />
        </ProtectedRoute>
      } />
      <Route path="/profile" element={
        <ProtectedRoute>
          <ProfilePage />
        </ProtectedRoute>
      } />
      
      {/* Provider routes */}
      <Route path="/provider" element={
        <ProtectedRoute allowedRoles={["driver", "electrician", "cleaner"]}>
          <ProviderDashboard />
        </ProtectedRoute>
      } />
      
      {/* Admin routes */}
      <Route path="/admin" element={
        <ProtectedRoute allowedRoles={["admin"]}>
          <AdminDashboard />
        </ProtectedRoute>
      } />
      
      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
        <Toaster 
          position="top-right"
          toastOptions={{
            style: {
              background: '#121212',
              border: '1px solid #262626',
              color: '#F5F5F5',
            },
          }}
        />
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
