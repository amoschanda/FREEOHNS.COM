import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';
import { ArrowLeft, Eye, EyeOff } from 'lucide-react';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      await register({
        full_name: formData.full_name,
        email: formData.email,
        phone: formData.phone,
        password: formData.password,
        role: 'customer'
      });
      toast.success('Account created successfully!');
      navigate('/dashboard');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex">
      {/* Left side - Image */}
      <div className="hidden lg:block lg:w-1/2 relative">
        <div className="absolute inset-0 bg-gradient-to-l from-[#050505] to-transparent z-10" />
        <img
          src="https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/o851l1ux_12fa3d2a-31fc-4c54-86e7-869f32ef560e.png"
          alt="FREEOHNS"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Right side - Form */}
      <div className="flex-1 flex flex-col justify-center px-8 sm:px-16 lg:px-24">
        <Link to="/" className="inline-flex items-center gap-2 text-[#A3A3A3] hover:text-white mb-8 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to home
        </Link>
        
        <div className="max-w-md w-full">
          <div className="flex items-center gap-3 mb-8">
            <img src={LOGO_URL} alt="FREEOHNS" className="h-12 w-auto" />
            <span className="text-2xl font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
              FREEOHNS
            </span>
          </div>
          
          <h1 className="text-3xl font-bold text-[#F5F5F5] mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
            Create your account
          </h1>
          <p className="text-[#A3A3A3] mb-8">Join FREEOHNS and start booking services</p>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="full_name" className="text-[#F5F5F5]">Full Name</Label>
              <Input
                id="full_name"
                name="full_name"
                type="text"
                value={formData.full_name}
                onChange={handleChange}
                placeholder="John Doe"
                required
                className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] h-12"
                data-testid="register-name-input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-[#F5F5F5]">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="you@example.com"
                required
                className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] h-12"
                data-testid="register-email-input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone" className="text-[#F5F5F5]">Phone Number</Label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+1 234 567 8900"
                required
                className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] h-12"
                data-testid="register-phone-input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-[#F5F5F5]">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="••••••••"
                  required
                  className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] h-12 pr-10"
                  data-testid="register-password-input"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#525252] hover:text-white"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-[#F5F5F5]">Confirm Password</Label>
              <Input
                id="confirmPassword"
                name="confirmPassword"
                type={showPassword ? 'text' : 'password'}
                value={formData.confirmPassword}
                onChange={handleChange}
                placeholder="••••••••"
                required
                className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] h-12"
                data-testid="register-confirm-password-input"
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-[#D4AF37] text-black hover:bg-[#F4C430] rounded-full h-12 font-semibold mt-2"
              data-testid="register-submit-btn"
            >
              {loading ? 'Creating account...' : 'Create Account'}
            </Button>
          </form>

          <p className="mt-8 text-center text-[#A3A3A3]">
            Already have an account?{' '}
            <Link to="/login" className="text-[#D4AF37] hover:text-[#F4C430] font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
