import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { 
  Shield, LogOut, User, Clock, MapPin, Phone, RefreshCw, 
  Car, Zap, Sparkles, Users, Calendar, TrendingUp, Check, X
} from 'lucide-react';
import axios from 'axios';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";
const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [users, setUsers] = useState([]);
  const [providers, setProviders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [filterService, setFilterService] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [statsRes, bookingsRes, usersRes, providersRes] = await Promise.all([
        axios.get(`${API_URL}/admin/stats`),
        axios.get(`${API_URL}/admin/bookings`),
        axios.get(`${API_URL}/admin/users?role=customer`),
        axios.get(`${API_URL}/admin/providers`)
      ]);
      setStats(statsRes.data);
      setBookings(bookingsRes.data);
      setUsers(usersRes.data);
      setProviders(providersRes.data);
    } catch (error) {
      toast.error('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateBookingStatus = async (bookingId, status) => {
    try {
      await axios.patch(`${API_URL}/bookings/${bookingId}`, { status });
      toast.success(`Booking ${status}`);
      fetchAllData();
    } catch (error) {
      toast.error('Failed to update booking');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-green-400 bg-green-400/10 border-green-400/20';
      case 'accepted': return 'text-blue-400 bg-blue-400/10 border-blue-400/20';
      case 'cancelled': return 'text-red-400 bg-red-400/10 border-red-400/20';
      default: return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
    }
  };

  const getServiceIcon = (type) => {
    switch (type) {
      case 'taxi': return Car;
      case 'electro_fix': return Zap;
      case 'cleaning': return Sparkles;
      default: return Car;
    }
  };

  const filteredBookings = bookings.filter(booking => {
    if (filterService !== 'all' && booking.service_type !== filterService) return false;
    if (filterStatus !== 'all' && booking.status !== filterStatus) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-[#050505]">
      {/* Header */}
      <header className="bg-[#0A0A0A] border-b border-[#262626] sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <img src={LOGO_URL} alt="FREEOHNS" className="h-9 w-auto" />
              <div>
                <span className="text-lg font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                  FREEOHNS
                </span>
                <p className="text-xs text-[#D4AF37]">Admin Panel</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/10">
                <Shield className="h-4 w-4 text-[#D4AF37]" />
                <span className="text-sm text-[#D4AF37]">Admin</span>
              </div>
              <Link to="/profile">
                <Button variant="ghost" className="text-[#A3A3A3] hover:text-white hover:bg-white/5" data-testid="profile-link">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Button
                variant="ghost"
                onClick={handleLogout}
                className="text-[#A3A3A3] hover:text-white hover:bg-white/5"
                data-testid="logout-btn"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
              Admin Dashboard
            </h1>
            <p className="text-[#A3A3A3]">Manage bookings, users, and providers</p>
          </div>
          <Button
            onClick={fetchAllData}
            variant="outline"
            className="border-[#333] text-[#A3A3A3] hover:text-white hover:bg-[#1A1A1A]"
            data-testid="refresh-btn"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-[#121212] border border-[#262626] mb-8">
              <TabsTrigger value="overview" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black" data-testid="overview-tab">
                Overview
              </TabsTrigger>
              <TabsTrigger value="bookings" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black" data-testid="bookings-tab">
                Bookings ({bookings.length})
              </TabsTrigger>
              <TabsTrigger value="users" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black" data-testid="users-tab">
                Customers ({users.length})
              </TabsTrigger>
              <TabsTrigger value="providers" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black" data-testid="providers-tab">
                Providers ({providers.length})
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview">
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <StatCard icon={Calendar} label="Total Bookings" value={stats?.total_bookings || 0} color="#D4AF37" />
                <StatCard icon={Clock} label="Pending" value={stats?.pending_bookings || 0} color="#F59E0B" />
                <StatCard icon={Check} label="Completed" value={stats?.completed_bookings || 0} color="#10B981" />
                <StatCard icon={Users} label="Total Customers" value={stats?.total_users || 0} color="#00E5FF" />
              </div>

              {/* Service Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="bg-[#121212] border border-[#262626] rounded-xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-[#D4AF37]/10 flex items-center justify-center">
                      <Car className="h-5 w-5 text-[#D4AF37]" />
                    </div>
                    <div>
                      <p className="text-[#525252] text-sm">Taxi Bookings</p>
                      <p className="text-2xl font-bold text-[#F5F5F5]">{stats?.service_breakdown?.taxi || 0}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-[#121212] border border-[#262626] rounded-xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-[#00E5FF]/10 flex items-center justify-center">
                      <Zap className="h-5 w-5 text-[#00E5FF]" />
                    </div>
                    <div>
                      <p className="text-[#525252] text-sm">Electro Fix</p>
                      <p className="text-2xl font-bold text-[#F5F5F5]">{stats?.service_breakdown?.electro_fix || 0}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-[#121212] border border-[#262626] rounded-xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-[#D4AF37]/10 flex items-center justify-center">
                      <Sparkles className="h-5 w-5 text-[#D4AF37]" />
                    </div>
                    <div>
                      <p className="text-[#525252] text-sm">Cleaning</p>
                      <p className="text-2xl font-bold text-[#F5F5F5]">{stats?.service_breakdown?.cleaning || 0}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Providers Count */}
              <div className="bg-[#121212] border border-[#262626] rounded-xl p-6">
                <h3 className="text-lg font-semibold text-[#F5F5F5] mb-4">Service Providers</h3>
                <div className="flex items-center gap-8">
                  <div>
                    <p className="text-4xl font-bold text-[#D4AF37]">{stats?.total_providers || 0}</p>
                    <p className="text-[#525252] text-sm">Total Providers</p>
                  </div>
                  <div className="flex-1 grid grid-cols-3 gap-4">
                    {['driver', 'electrician', 'cleaner'].map((role) => {
                      const count = providers.filter(p => p.role === role).length;
                      const Icon = role === 'driver' ? Car : role === 'electrician' ? Zap : Sparkles;
                      return (
                        <div key={role} className="text-center p-3 bg-[#1A1A1A] rounded-lg">
                          <Icon className="h-5 w-5 mx-auto mb-1 text-[#A3A3A3]" />
                          <p className="text-lg font-semibold text-[#F5F5F5]">{count}</p>
                          <p className="text-xs text-[#525252] capitalize">{role}s</p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Bookings Tab */}
            <TabsContent value="bookings">
              {/* Filters */}
              <div className="flex gap-4 mb-6">
                <Select value={filterService} onValueChange={setFilterService}>
                  <SelectTrigger className="w-[180px] bg-[#1A1A1A] border-[#333] text-white">
                    <SelectValue placeholder="Filter by service" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1A1A1A] border-[#333]">
                    <SelectItem value="all" className="text-white">All Services</SelectItem>
                    <SelectItem value="taxi" className="text-white">Taxi</SelectItem>
                    <SelectItem value="electro_fix" className="text-white">Electro Fix</SelectItem>
                    <SelectItem value="cleaning" className="text-white">Cleaning</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-[180px] bg-[#1A1A1A] border-[#333] text-white">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1A1A1A] border-[#333]">
                    <SelectItem value="all" className="text-white">All Status</SelectItem>
                    <SelectItem value="pending" className="text-white">Pending</SelectItem>
                    <SelectItem value="accepted" className="text-white">Accepted</SelectItem>
                    <SelectItem value="completed" className="text-white">Completed</SelectItem>
                    <SelectItem value="cancelled" className="text-white">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {filteredBookings.length === 0 ? (
                <div className="text-center py-16 bg-[#121212] border border-[#262626] rounded-2xl">
                  <Calendar className="h-12 w-12 text-[#525252] mx-auto mb-4" />
                  <p className="text-[#A3A3A3]">No bookings found</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredBookings.map((booking) => {
                    const ServiceIcon = getServiceIcon(booking.service_type);
                    return (
                      <div key={booking.id} className="bg-[#121212] border border-[#262626] rounded-xl p-6" data-testid={`admin-booking-${booking.id}`}>
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center gap-4">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                              booking.service_type === 'electro_fix' ? 'bg-[#00E5FF]/10' : 'bg-[#D4AF37]/10'
                            }`}>
                              <ServiceIcon className={`h-5 w-5 ${
                                booking.service_type === 'electro_fix' ? 'text-[#00E5FF]' : 'text-[#D4AF37]'
                              }`} />
                            </div>
                            <div>
                              <p className="text-[#F5F5F5] font-semibold">
                                {booking.service_type === 'taxi' ? 'Taxi Ride' : booking.service_type === 'electro_fix' ? 'Electro Fix' : 'Cleaning'}
                              </p>
                              <p className="text-[#525252] text-xs font-mono">{booking.id}</p>
                            </div>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(booking.status)}`}>
                            {booking.status}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                          <div>
                            <p className="text-[#525252]">Customer</p>
                            <p className="text-[#F5F5F5]">{booking.user_name}</p>
                          </div>
                          <div>
                            <p className="text-[#525252]">Phone</p>
                            <p className="text-[#F5F5F5]">{booking.user_phone}</p>
                          </div>
                          <div>
                            <p className="text-[#525252]">Date & Time</p>
                            <p className="text-[#F5F5F5]">{booking.scheduled_date} {booking.scheduled_time}</p>
                          </div>
                          <div>
                            <p className="text-[#525252]">Provider</p>
                            <p className="text-[#F5F5F5]">{booking.provider_name || 'Unassigned'}</p>
                          </div>
                        </div>

                        {booking.status === 'pending' && (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={() => handleUpdateBookingStatus(booking.id, 'cancelled')}
                              variant="outline"
                              className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                            >
                              <X className="h-4 w-4 mr-1" />
                              Cancel
                            </Button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            {/* Users Tab */}
            <TabsContent value="users">
              {users.length === 0 ? (
                <div className="text-center py-16 bg-[#121212] border border-[#262626] rounded-2xl">
                  <Users className="h-12 w-12 text-[#525252] mx-auto mb-4" />
                  <p className="text-[#A3A3A3]">No customers yet</p>
                </div>
              ) : (
                <div className="bg-[#121212] border border-[#262626] rounded-xl overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-[#1A1A1A]">
                      <tr>
                        <th className="text-left p-4 text-[#525252] font-medium">Name</th>
                        <th className="text-left p-4 text-[#525252] font-medium">Email</th>
                        <th className="text-left p-4 text-[#525252] font-medium">Phone</th>
                        <th className="text-left p-4 text-[#525252] font-medium">Joined</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((user) => (
                        <tr key={user.id} className="border-t border-[#262626]" data-testid={`user-row-${user.id}`}>
                          <td className="p-4 text-[#F5F5F5]">{user.full_name}</td>
                          <td className="p-4 text-[#A3A3A3]">{user.email}</td>
                          <td className="p-4 text-[#A3A3A3]">{user.phone}</td>
                          <td className="p-4 text-[#525252]">
                            {new Date(user.created_at).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </TabsContent>

            {/* Providers Tab */}
            <TabsContent value="providers">
              {providers.length === 0 ? (
                <div className="text-center py-16 bg-[#121212] border border-[#262626] rounded-2xl">
                  <Users className="h-12 w-12 text-[#525252] mx-auto mb-4" />
                  <p className="text-[#A3A3A3]">No providers registered yet</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {providers.map((provider) => {
                    const Icon = provider.role === 'driver' ? Car : provider.role === 'electrician' ? Zap : Sparkles;
                    const color = provider.role === 'electrician' ? '#00E5FF' : '#D4AF37';
                    return (
                      <div key={provider.id} className="bg-[#121212] border border-[#262626] rounded-xl p-6" data-testid={`provider-card-${provider.id}`}>
                        <div className="flex items-center gap-4 mb-4">
                          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: `${color}15` }}>
                            <Icon className="h-6 w-6" style={{ color }} />
                          </div>
                          <div>
                            <p className="text-[#F5F5F5] font-semibold">{provider.full_name}</p>
                            <p className="text-xs capitalize" style={{ color }}>{provider.role}</p>
                          </div>
                        </div>
                        <div className="space-y-2 text-sm">
                          <p className="text-[#A3A3A3]">{provider.email}</p>
                          <p className="text-[#A3A3A3]">{provider.phone}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </TabsContent>
          </Tabs>
        )}
      </main>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <div className="bg-[#121212] border border-[#262626] rounded-xl p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[#525252] text-sm mb-1">{label}</p>
          <p className="text-3xl font-bold" style={{ color }}>{value}</p>
        </div>
        <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: `${color}15` }}>
          <Icon className="h-6 w-6" style={{ color }} />
        </div>
      </div>
    </div>
  );
}
