import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';
import { ArrowLeft, User, Mail, Phone, Calendar, LogOut } from 'lucide-react';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const getRoleDisplay = (role) => {
    switch (role) {
      case 'customer': return 'Customer';
      case 'driver': return 'Driver';
      case 'electrician': return 'Electrician';
      case 'cleaner': return 'Cleaner';
      case 'admin': return 'Administrator';
      default: return role;
    }
  };

  const getBackLink = () => {
    if (user?.role === 'admin') return '/admin';
    if (['driver', 'electrician', 'cleaner'].includes(user?.role)) return '/provider';
    return '/dashboard';
  };

  return (
    <div className="min-h-screen bg-[#050505]">
      {/* Header */}
      <header className="bg-[#0A0A0A] border-b border-[#262626]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <img src={LOGO_URL} alt="FREEOHNS" className="h-9 w-auto" />
              <span className="text-lg font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                FREEOHNS
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to={getBackLink()} className="inline-flex items-center gap-2 text-[#A3A3A3] hover:text-white mb-6 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>

        <div className="bg-[#121212] border border-[#262626] rounded-2xl overflow-hidden">
          {/* Profile Header */}
          <div className="bg-gradient-to-r from-[#D4AF37]/20 to-[#00E5FF]/20 p-8">
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 rounded-full bg-[#D4AF37] flex items-center justify-center">
                <span className="text-3xl font-bold text-black">
                  {user?.full_name?.charAt(0).toUpperCase()}
                </span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                  {user?.full_name}
                </h1>
                <span className="inline-block mt-1 px-3 py-1 rounded-full text-xs font-medium bg-[#D4AF37]/20 text-[#D4AF37]">
                  {getRoleDisplay(user?.role)}
                </span>
              </div>
            </div>
          </div>

          {/* Profile Details */}
          <div className="p-8 space-y-6">
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 bg-[#1A1A1A] rounded-xl">
                <div className="w-10 h-10 rounded-full bg-[#262626] flex items-center justify-center">
                  <User className="h-5 w-5 text-[#A3A3A3]" />
                </div>
                <div>
                  <p className="text-xs text-[#525252]">Full Name</p>
                  <p className="text-[#F5F5F5]">{user?.full_name}</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-[#1A1A1A] rounded-xl">
                <div className="w-10 h-10 rounded-full bg-[#262626] flex items-center justify-center">
                  <Mail className="h-5 w-5 text-[#A3A3A3]" />
                </div>
                <div>
                  <p className="text-xs text-[#525252]">Email Address</p>
                  <p className="text-[#F5F5F5]">{user?.email}</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-[#1A1A1A] rounded-xl">
                <div className="w-10 h-10 rounded-full bg-[#262626] flex items-center justify-center">
                  <Phone className="h-5 w-5 text-[#A3A3A3]" />
                </div>
                <div>
                  <p className="text-xs text-[#525252]">Phone Number</p>
                  <p className="text-[#F5F5F5]">{user?.phone || 'Not provided'}</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-[#1A1A1A] rounded-xl">
                <div className="w-10 h-10 rounded-full bg-[#262626] flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-[#A3A3A3]" />
                </div>
                <div>
                  <p className="text-xs text-[#525252]">Member Since</p>
                  <p className="text-[#F5F5F5]">
                    {user?.created_at ? new Date(user.created_at).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    }) : 'N/A'}
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-[#262626]">
              <Button
                onClick={handleLogout}
                variant="outline"
                className="w-full border-red-500/50 text-red-400 hover:bg-red-500/10 rounded-full h-12"
                data-testid="logout-btn"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
