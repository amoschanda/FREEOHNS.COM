import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { toast } from 'sonner';
import { ArrowLeft, Eye, EyeOff, Car, Zap, Sparkles } from 'lucide-react';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";

export default function ProviderLoginPage() {
  const [activeTab, setActiveTab] = useState('login');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Login state
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  
  // Register state
  const [registerData, setRegisterData] = useState({
    full_name: '',
    email: '',
    phone: '',
    password: '',
    role: '',
    vehicle_info: '',
    experience: ''
  });

  const { login, register } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(loginData.email, loginData.password);
      if (!['driver', 'electrician', 'cleaner'].includes(user.role)) {
        toast.error('This login is for service providers only');
        return;
      }
      toast.success('Welcome back!');
      navigate('/provider');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Invalid credentials');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!registerData.role) {
      toast.error('Please select your service type');
      return;
    }
    setLoading(true);
    try {
      await register(registerData);
      toast.success('Provider account created!');
      navigate('/provider');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const roleIcons = {
    driver: Car,
    electrician: Zap,
    cleaner: Sparkles
  };

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <Link to="/" className="inline-flex items-center gap-2 text-[#A3A3A3] hover:text-white mb-8 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to home
        </Link>

        <div className="bg-[#121212] border border-[#262626] rounded-2xl p-8">
          <div className="flex items-center gap-3 mb-6">
            <img src={LOGO_URL} alt="FREEOHNS" className="h-10 w-auto" />
            <div>
              <span className="text-xl font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                FREEOHNS
              </span>
              <p className="text-xs text-[#00E5FF]">Provider Portal</p>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 bg-[#1A1A1A] mb-6">
              <TabsTrigger value="login" className="data-[state=active]:bg-[#00E5FF] data-[state=active]:text-black">
                Sign In
              </TabsTrigger>
              <TabsTrigger value="register" className="data-[state=active]:bg-[#00E5FF] data-[state=active]:text-black">
                Register
              </TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="login-email" className="text-[#F5F5F5]">Email</Label>
                  <Input
                    id="login-email"
                    type="email"
                    value={loginData.email}
                    onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                    placeholder="provider@example.com"
                    required
                    className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#00E5FF] focus:ring-1 focus:ring-[#00E5FF] h-12"
                    data-testid="provider-login-email"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="login-password" className="text-[#F5F5F5]">Password</Label>
                  <div className="relative">
                    <Input
                      id="login-password"
                      type={showPassword ? 'text' : 'password'}
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      placeholder="••••••••"
                      required
                      className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#00E5FF] focus:ring-1 focus:ring-[#00E5FF] h-12 pr-10"
                      data-testid="provider-login-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#525252] hover:text-white"
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-[#00E5FF] text-black hover:bg-[#5FFFFF] rounded-full h-12 font-semibold"
                  data-testid="provider-login-submit"
                >
                  {loading ? 'Signing in...' : 'Sign In'}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="register">
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="reg-name" className="text-[#F5F5F5]">Full Name</Label>
                  <Input
                    id="reg-name"
                    type="text"
                    value={registerData.full_name}
                    onChange={(e) => setRegisterData({ ...registerData, full_name: e.target.value })}
                    placeholder="John Doe"
                    required
                    className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#00E5FF] h-11"
                    data-testid="provider-register-name"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reg-email" className="text-[#F5F5F5]">Email</Label>
                  <Input
                    id="reg-email"
                    type="email"
                    value={registerData.email}
                    onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                    placeholder="provider@example.com"
                    required
                    className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#00E5FF] h-11"
                    data-testid="provider-register-email"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reg-phone" className="text-[#F5F5F5]">Phone</Label>
                  <Input
                    id="reg-phone"
                    type="tel"
                    value={registerData.phone}
                    onChange={(e) => setRegisterData({ ...registerData, phone: e.target.value })}
                    placeholder="+1 234 567 8900"
                    required
                    className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#00E5FF] h-11"
                    data-testid="provider-register-phone"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-[#F5F5F5]">Service Type</Label>
                  <Select
                    value={registerData.role}
                    onValueChange={(value) => setRegisterData({ ...registerData, role: value })}
                  >
                    <SelectTrigger className="bg-[#1A1A1A] border-[#333] text-white h-11" data-testid="provider-register-role">
                      <SelectValue placeholder="Select your service" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1A1A1A] border-[#333]">
                      <SelectItem value="driver" className="text-white hover:bg-[#262626]">
                        <div className="flex items-center gap-2">
                          <Car className="h-4 w-4 text-[#D4AF37]" />
                          Driver (Taxi)
                        </div>
                      </SelectItem>
                      <SelectItem value="electrician" className="text-white hover:bg-[#262626]">
                        <div className="flex items-center gap-2">
                          <Zap className="h-4 w-4 text-[#00E5FF]" />
                          Electrician
                        </div>
                      </SelectItem>
                      <SelectItem value="cleaner" className="text-white hover:bg-[#262626]">
                        <div className="flex items-center gap-2">
                          <Sparkles className="h-4 w-4 text-[#D4AF37]" />
                          Cleaner
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reg-password" className="text-[#F5F5F5]">Password</Label>
                  <Input
                    id="reg-password"
                    type={showPassword ? 'text' : 'password'}
                    value={registerData.password}
                    onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                    placeholder="••••••••"
                    required
                    className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#00E5FF] h-11"
                    data-testid="provider-register-password"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-[#00E5FF] text-black hover:bg-[#5FFFFF] rounded-full h-12 font-semibold"
                  data-testid="provider-register-submit"
                >
                  {loading ? 'Creating account...' : 'Register as Provider'}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>

        <p className="mt-6 text-center text-sm text-[#525252]">
          Looking to book a service?{' '}
          <Link to="/login" className="text-[#D4AF37] hover:text-[#F4C430]">
            Customer Login
          </Link>
        </p>
      </div>
    </div>
  );
}
