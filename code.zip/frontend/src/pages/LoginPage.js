import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';
import { ArrowLeft, Eye, EyeOff } from 'lucide-react';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(email, password);
      toast.success('Welcome back!');
      if (user.role === 'admin') {
        navigate('/admin');
      } else if (['driver', 'electrician', 'cleaner'].includes(user.role)) {
        navigate('/provider');
      } else {
        navigate('/dashboard');
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Invalid credentials');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex">
      {/* Left side - Form */}
      <div className="flex-1 flex flex-col justify-center px-8 sm:px-16 lg:px-24">
        <Link to="/" className="inline-flex items-center gap-2 text-[#A3A3A3] hover:text-white mb-12 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to home
        </Link>
        
        <div className="max-w-md w-full">
          <div className="flex items-center gap-3 mb-8">
            <img src={LOGO_URL} alt="FREEOHNS" className="h-12 w-auto" />
            <span className="text-2xl font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
              FREEOHNS
            </span>
          </div>
          
          <h1 className="text-3xl font-bold text-[#F5F5F5] mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
            Welcome back
          </h1>
          <p className="text-[#A3A3A3] mb-8">Sign in to your account to continue</p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-[#F5F5F5]">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] h-12"
                data-testid="login-email-input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-[#F5F5F5]">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] h-12 pr-10"
                  data-testid="login-password-input"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#525252] hover:text-white"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-[#D4AF37] text-black hover:bg-[#F4C430] rounded-full h-12 font-semibold"
              data-testid="login-submit-btn"
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </Button>
          </form>

          <p className="mt-8 text-center text-[#A3A3A3]">
            Don't have an account?{' '}
            <Link to="/register" className="text-[#D4AF37] hover:text-[#F4C430] font-medium">
              Sign up
            </Link>
          </p>

          <div className="mt-8 pt-8 border-t border-[#262626]">
            <p className="text-sm text-[#525252] text-center">
              Are you a service provider?{' '}
              <Link to="/provider-login" className="text-[#00E5FF] hover:text-[#5FFFFF]">
                Provider Login
              </Link>
            </p>
          </div>
        </div>
      </div>

      {/* Right side - Image */}
      <div className="hidden lg:block lg:w-1/2 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-[#050505] to-transparent z-10" />
        <img
          src="https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/hhgk9afl_3b8c987f-69cf-4831-9dae-b0613495644f.png"
          alt="FREEOHNS"
          className="w-full h-full object-cover"
        />
      </div>
    </div>
  );
}
