import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Car, Zap, Sparkles, LogOut, User, Clock, ChevronRight } from 'lucide-react';
import axios from 'axios';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";
const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

const services = [
  {
    id: 'taxi',
    name: 'Book Your Ride',
    description: 'Reliable, Affordable, Convenient taxi service',
    icon: Car,
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/hhgk9afl_3b8c987f-69cf-4831-9dae-b0613495644f.png',
    features: ['Easy Booking', 'Safe Rides', '24/7 Support'],
    accent: 'gold',
    buttonText: 'Book a Ride'
  },
  {
    id: 'electro_fix',
    name: 'Electro Fix',
    description: 'Power Up Your Home - Reliable, Affordable, Safe',
    icon: Zap,
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/z4g9ce4s_71f01b27-ffdb-4d31-ab3c-785fc8e5fb97.jpeg',
    features: ['Easy Scheduling', 'Certified Technicians', '24/7 Support'],
    accent: 'cyan',
    buttonText: 'Schedule Service'
  },
  {
    id: 'cleaning',
    name: 'Book Your Clean',
    description: 'Reliable, Affordable, Thorough cleaning service',
    icon: Sparkles,
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/o851l1ux_12fa3d2a-31fc-4c54-86e7-869f32ef560e.png',
    features: ['Easy Scheduling', 'Thorough Cleaning', '24/7 Support'],
    accent: 'gold',
    buttonText: 'Book Cleaning'
  }
];

export default function CustomerDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [recentBookings, setRecentBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecentBookings();
  }, []);

  const fetchRecentBookings = async () => {
    try {
      const response = await axios.get(`${API_URL}/bookings`);
      setRecentBookings(response.data.slice(0, 3));
    } catch (error) {
      console.error('Failed to fetch bookings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-green-400 bg-green-400/10';
      case 'accepted': return 'text-blue-400 bg-blue-400/10';
      case 'cancelled': return 'text-red-400 bg-red-400/10';
      default: return 'text-yellow-400 bg-yellow-400/10';
    }
  };

  const getServiceIcon = (type) => {
    switch (type) {
      case 'taxi': return Car;
      case 'electro_fix': return Zap;
      case 'cleaning': return Sparkles;
      default: return Car;
    }
  };

  return (
    <div className="min-h-screen bg-[#050505]">
      {/* Header */}
      <header className="bg-[#0A0A0A] border-b border-[#262626] sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <img src={LOGO_URL} alt="FREEOHNS" className="h-9 w-auto" />
              <span className="text-lg font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                FREEOHNS
              </span>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/bookings">
                <Button variant="ghost" className="text-[#A3A3A3] hover:text-white hover:bg-white/5" data-testid="bookings-link">
                  <Clock className="h-4 w-4 mr-2" />
                  My Bookings
                </Button>
              </Link>
              <Link to="/profile">
                <Button variant="ghost" className="text-[#A3A3A3] hover:text-white hover:bg-white/5" data-testid="profile-link">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Button
                variant="ghost"
                onClick={handleLogout}
                className="text-[#A3A3A3] hover:text-white hover:bg-white/5"
                data-testid="logout-btn"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-10">
          <h1 className="text-3xl font-bold text-[#F5F5F5] mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
            Welcome back, {user?.full_name?.split(' ')[0]}!
          </h1>
          <p className="text-[#A3A3A3]">What service do you need today?</p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {services.map((service) => (
            <div
              key={service.id}
              className="group relative overflow-hidden rounded-2xl bg-[#121212] border border-[#262626] hover:border-[#D4AF37]/50 transition-all duration-300"
              data-testid={`service-card-${service.id}`}
            >
              <div className="aspect-[16/10] overflow-hidden">
                <img
                  src={service.image}
                  alt={service.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/60 to-transparent" />
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full mb-3 ${
                  service.accent === 'cyan' ? 'bg-[#00E5FF]/10 text-[#00E5FF]' : 'bg-[#D4AF37]/10 text-[#D4AF37]'
                }`}>
                  <service.icon className="h-4 w-4" />
                  <span className="text-sm font-medium">{service.name}</span>
                </div>
                <p className="text-[#A3A3A3] text-sm mb-4">{service.description}</p>
                <Link to={`/book/${service.id}`}>
                  <Button 
                    className={`w-full rounded-full font-semibold ${
                      service.accent === 'cyan' 
                        ? 'bg-[#00E5FF] text-black hover:bg-[#5FFFFF]' 
                        : 'bg-[#D4AF37] text-black hover:bg-[#F4C430]'
                    }`}
                    data-testid={`book-${service.id}-btn`}
                  >
                    {service.buttonText}
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* Recent Bookings */}
        <div className="bg-[#121212] border border-[#262626] rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
              Recent Bookings
            </h2>
            <Link to="/bookings">
              <Button variant="ghost" className="text-[#D4AF37] hover:text-[#F4C430] hover:bg-[#D4AF37]/10">
                View All
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-8 h-8 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin" />
            </div>
          ) : recentBookings.length === 0 ? (
            <div className="text-center py-12">
              <Clock className="h-12 w-12 text-[#525252] mx-auto mb-4" />
              <p className="text-[#A3A3A3]">No bookings yet</p>
              <p className="text-[#525252] text-sm">Book a service to get started</p>
            </div>
          ) : (
            <div className="space-y-4">
              {recentBookings.map((booking) => {
                const ServiceIcon = getServiceIcon(booking.service_type);
                return (
                  <div
                    key={booking.id}
                    className="flex items-center gap-4 p-4 bg-[#1A1A1A] rounded-xl"
                    data-testid={`booking-item-${booking.id}`}
                  >
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      booking.service_type === 'electro_fix' ? 'bg-[#00E5FF]/10' : 'bg-[#D4AF37]/10'
                    }`}>
                      <ServiceIcon className={`h-6 w-6 ${
                        booking.service_type === 'electro_fix' ? 'text-[#00E5FF]' : 'text-[#D4AF37]'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <p className="text-[#F5F5F5] font-medium">
                        {booking.service_type === 'taxi' && 'Taxi Ride'}
                        {booking.service_type === 'electro_fix' && 'Electrical Service'}
                        {booking.service_type === 'cleaning' && 'Cleaning Service'}
                      </p>
                      <p className="text-[#525252] text-sm">
                        {booking.scheduled_date} at {booking.scheduled_time}
                      </p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(booking.status)}`}>
                      {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
