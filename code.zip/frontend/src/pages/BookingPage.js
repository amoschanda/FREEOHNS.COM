import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Calendar } from '../components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../components/ui/popover';
import { toast } from 'sonner';
import { ArrowLeft, Car, Zap, Sparkles, CalendarIcon, Clock } from 'lucide-react';
import { format } from 'date-fns';
import axios from 'axios';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";
const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

const serviceConfig = {
  taxi: {
    name: 'Book Your Ride',
    icon: Car,
    accent: 'gold',
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/hhgk9afl_3b8c987f-69cf-4831-9dae-b0613495644f.png'
  },
  electro_fix: {
    name: 'Electro Fix',
    icon: Zap,
    accent: 'cyan',
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/z4g9ce4s_71f01b27-ffdb-4d31-ab3c-785fc8e5fb97.jpeg'
  },
  cleaning: {
    name: 'Book Your Clean',
    icon: Sparkles,
    accent: 'gold',
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/o851l1ux_12fa3d2a-31fc-4c54-86e7-869f32ef560e.png'
  }
};

const vehicleTypes = ['Sedan', 'SUV', 'Van', 'Luxury'];
const issueTypes = ['Wiring Issues', 'Outlet Installation', 'Circuit Breaker', 'Lighting', 'Panel Upgrade', 'Other'];
const propertyTypes = ['Apartment', 'House', 'Office', 'Commercial'];
const cleaningTypes = ['Regular Cleaning', 'Deep Cleaning', 'Move-in/Move-out', 'Post-Construction'];
const timeSlots = ['08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM', '06:00 PM'];

export default function BookingPage() {
  const { serviceId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [date, setDate] = useState(null);
  
  const [formData, setFormData] = useState({
    pickup_address: '',
    dropoff_address: '',
    service_address: '',
    scheduled_time: '',
    notes: '',
    vehicle_type: '',
    issue_type: '',
    property_type: '',
    cleaning_type: ''
  });

  const service = serviceConfig[serviceId];
  
  if (!service) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="text-center">
          <p className="text-[#A3A3A3] mb-4">Service not found</p>
          <Link to="/dashboard">
            <Button className="bg-[#D4AF37] text-black hover:bg-[#F4C430]">
              Go to Dashboard
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleChange = (name, value) => {
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!date) {
      toast.error('Please select a date');
      return;
    }
    
    if (!formData.scheduled_time) {
      toast.error('Please select a time');
      return;
    }

    // Validate service-specific fields
    if (serviceId === 'taxi') {
      if (!formData.pickup_address || !formData.dropoff_address) {
        toast.error('Please enter pickup and dropoff addresses');
        return;
      }
    } else {
      if (!formData.service_address) {
        toast.error('Please enter the service address');
        return;
      }
    }

    setLoading(true);
    try {
      const bookingData = {
        service_type: serviceId,
        scheduled_date: format(date, 'yyyy-MM-dd'),
        scheduled_time: formData.scheduled_time,
        notes: formData.notes,
        pickup_address: formData.pickup_address || null,
        dropoff_address: formData.dropoff_address || null,
        service_address: formData.service_address || null,
        vehicle_type: formData.vehicle_type || null,
        issue_type: formData.issue_type || null,
        property_type: formData.property_type || null,
        cleaning_type: formData.cleaning_type || null
      };

      await axios.post(`${API_URL}/bookings`, bookingData);
      toast.success('Booking created successfully!');
      navigate('/bookings');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to create booking');
    } finally {
      setLoading(false);
    }
  };

  const ServiceIcon = service.icon;
  const accentColor = service.accent === 'cyan' ? '#00E5FF' : '#D4AF37';
  const accentColorHover = service.accent === 'cyan' ? '#5FFFFF' : '#F4C430';

  return (
    <div className="min-h-screen bg-[#050505]">
      {/* Header */}
      <header className="bg-[#0A0A0A] border-b border-[#262626]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <img src={LOGO_URL} alt="FREEOHNS" className="h-9 w-auto" />
              <span className="text-lg font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                FREEOHNS
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to="/dashboard" className="inline-flex items-center gap-2 text-[#A3A3A3] hover:text-white mb-6 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Service Info */}
          <div className="lg:col-span-2">
            <div className="sticky top-24">
              <div className="rounded-2xl overflow-hidden mb-6">
                <img src={service.image} alt={service.name} className="w-full aspect-[4/3] object-cover" />
              </div>
              <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4`}
                style={{ backgroundColor: `${accentColor}15`, color: accentColor }}>
                <ServiceIcon className="h-5 w-5" />
                <span className="font-medium">{service.name}</span>
              </div>
              <p className="text-[#A3A3A3] text-sm">
                {serviceId === 'taxi' && 'Book a reliable ride to your destination. Our drivers are professional and punctual.'}
                {serviceId === 'electro_fix' && 'Professional electricians ready to fix any electrical issues in your home or office.'}
                {serviceId === 'cleaning' && 'Expert cleaning services for homes, offices, and commercial spaces.'}
              </p>
            </div>
          </div>

          {/* Booking Form */}
          <div className="lg:col-span-3">
            <div className="bg-[#121212] border border-[#262626] rounded-2xl p-6">
              <h1 className="text-2xl font-bold text-[#F5F5F5] mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                Book {service.name}
              </h1>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Taxi-specific fields */}
                {serviceId === 'taxi' && (
                  <>
                    <div className="space-y-2">
                      <Label className="text-[#F5F5F5]">Pickup Address</Label>
                      <Input
                        value={formData.pickup_address}
                        onChange={(e) => handleChange('pickup_address', e.target.value)}
                        placeholder="Enter pickup location"
                        className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] h-12"
                        data-testid="pickup-address-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[#F5F5F5]">Dropoff Address</Label>
                      <Input
                        value={formData.dropoff_address}
                        onChange={(e) => handleChange('dropoff_address', e.target.value)}
                        placeholder="Enter destination"
                        className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] h-12"
                        data-testid="dropoff-address-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[#F5F5F5]">Vehicle Type</Label>
                      <Select value={formData.vehicle_type} onValueChange={(v) => handleChange('vehicle_type', v)}>
                        <SelectTrigger className="bg-[#1A1A1A] border-[#333] text-white h-12" data-testid="vehicle-type-select">
                          <SelectValue placeholder="Select vehicle type" />
                        </SelectTrigger>
                        <SelectContent className="bg-[#1A1A1A] border-[#333]">
                          {vehicleTypes.map((type) => (
                            <SelectItem key={type} value={type} className="text-white hover:bg-[#262626]">
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                {/* Electro Fix specific fields */}
                {serviceId === 'electro_fix' && (
                  <>
                    <div className="space-y-2">
                      <Label className="text-[#F5F5F5]">Service Address</Label>
                      <Input
                        value={formData.service_address}
                        onChange={(e) => handleChange('service_address', e.target.value)}
                        placeholder="Enter your address"
                        className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#00E5FF] h-12"
                        data-testid="service-address-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[#F5F5F5]">Issue Type</Label>
                      <Select value={formData.issue_type} onValueChange={(v) => handleChange('issue_type', v)}>
                        <SelectTrigger className="bg-[#1A1A1A] border-[#333] text-white h-12" data-testid="issue-type-select">
                          <SelectValue placeholder="Select issue type" />
                        </SelectTrigger>
                        <SelectContent className="bg-[#1A1A1A] border-[#333]">
                          {issueTypes.map((type) => (
                            <SelectItem key={type} value={type} className="text-white hover:bg-[#262626]">
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                {/* Cleaning specific fields */}
                {serviceId === 'cleaning' && (
                  <>
                    <div className="space-y-2">
                      <Label className="text-[#F5F5F5]">Service Address</Label>
                      <Input
                        value={formData.service_address}
                        onChange={(e) => handleChange('service_address', e.target.value)}
                        placeholder="Enter your address"
                        className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] h-12"
                        data-testid="service-address-input"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="text-[#F5F5F5]">Property Type</Label>
                        <Select value={formData.property_type} onValueChange={(v) => handleChange('property_type', v)}>
                          <SelectTrigger className="bg-[#1A1A1A] border-[#333] text-white h-12" data-testid="property-type-select">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent className="bg-[#1A1A1A] border-[#333]">
                            {propertyTypes.map((type) => (
                              <SelectItem key={type} value={type} className="text-white hover:bg-[#262626]">
                                {type}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-[#F5F5F5]">Cleaning Type</Label>
                        <Select value={formData.cleaning_type} onValueChange={(v) => handleChange('cleaning_type', v)}>
                          <SelectTrigger className="bg-[#1A1A1A] border-[#333] text-white h-12" data-testid="cleaning-type-select">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent className="bg-[#1A1A1A] border-[#333]">
                            {cleaningTypes.map((type) => (
                              <SelectItem key={type} value={type} className="text-white hover:bg-[#262626]">
                                {type}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                )}

                {/* Date and Time */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-[#F5F5F5]">Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal bg-[#1A1A1A] border-[#333] text-white hover:bg-[#262626] h-12"
                          data-testid="date-picker-trigger"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {date ? format(date, 'PPP') : 'Pick a date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0 bg-[#1A1A1A] border-[#333]" align="start">
                        <Calendar
                          mode="single"
                          selected={date}
                          onSelect={setDate}
                          disabled={(date) => date < new Date()}
                          className="bg-[#1A1A1A] text-white"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[#F5F5F5]">Time</Label>
                    <Select value={formData.scheduled_time} onValueChange={(v) => handleChange('scheduled_time', v)}>
                      <SelectTrigger className="bg-[#1A1A1A] border-[#333] text-white h-12" data-testid="time-select">
                        <Clock className="mr-2 h-4 w-4" />
                        <SelectValue placeholder="Select time" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1A1A1A] border-[#333] max-h-60">
                        {timeSlots.map((time) => (
                          <SelectItem key={time} value={time} className="text-white hover:bg-[#262626]">
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Notes */}
                <div className="space-y-2">
                  <Label className="text-[#F5F5F5]">Additional Notes (Optional)</Label>
                  <Textarea
                    value={formData.notes}
                    onChange={(e) => handleChange('notes', e.target.value)}
                    placeholder="Any special instructions..."
                    className="bg-[#1A1A1A] border-[#333] text-white focus:border-[#D4AF37] min-h-[100px]"
                    data-testid="notes-input"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full rounded-full h-12 font-semibold"
                  style={{ backgroundColor: accentColor, color: '#000' }}
                  data-testid="submit-booking-btn"
                >
                  {loading ? 'Creating Booking...' : 'Confirm Booking'}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
