import { Link } from 'react-router-dom';
import { Car, Zap, Sparkles, Phone, Shield, Clock, ChevronRight } from 'lucide-react';
import { Button } from '../components/ui/button';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";

const services = [
  {
    id: 'taxi',
    name: 'Book Your Ride',
    description: 'Reliable, Affordable, Convenient',
    icon: Car,
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/hhgk9afl_3b8c987f-69cf-4831-9dae-b0613495644f.png',
    features: ['Easy Booking', 'Safe Rides', '24/7 Support'],
    accent: 'gold'
  },
  {
    id: 'electro_fix',
    name: 'Electro Fix',
    description: 'Power Up Your Home',
    icon: Zap,
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/z4g9ce4s_71f01b27-ffdb-4d31-ab3c-785fc8e5fb97.jpeg',
    features: ['Easy Scheduling', 'Certified Technicians', '24/7 Support'],
    accent: 'cyan'
  },
  {
    id: 'cleaning',
    name: 'Book Your Clean',
    description: 'Reliable, Affordable, Thorough',
    icon: Sparkles,
    image: 'https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/o851l1ux_12fa3d2a-31fc-4c54-86e7-869f32ef560e.png',
    features: ['Easy Scheduling', 'Thorough Cleaning', '24/7 Support'],
    accent: 'gold'
  }
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#050505]">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#050505]/80 backdrop-blur-xl border-b border-[#262626]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <img src={LOGO_URL} alt="FREEOHNS" className="h-10 w-auto" />
              <span className="text-xl font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                FREEOHNS
              </span>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/provider-login">
                <Button variant="ghost" className="text-[#A3A3A3] hover:text-white hover:bg-white/5" data-testid="provider-login-btn">
                  Provider Login
                </Button>
              </Link>
              <Link to="/admin-login">
                <Button variant="ghost" className="text-[#A3A3A3] hover:text-white hover:bg-white/5" data-testid="admin-login-btn">
                  Admin
                </Button>
              </Link>
              <Link to="/login">
                <Button variant="outline" className="border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37]/10 rounded-full px-6" data-testid="login-btn">
                  Sign In
                </Button>
              </Link>
              <Link to="/register">
                <Button className="bg-[#D4AF37] text-black hover:bg-[#F4C430] rounded-full px-6 font-semibold" data-testid="register-btn">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 stagger-children">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
              <span className="text-[#F5F5F5]">Your Services,</span>
              <br />
              <span className="text-gradient-gold">One Platform</span>
            </h1>
            <p className="text-xl text-[#A3A3A3] max-w-2xl mx-auto mb-8">
              Book rides, schedule electrical repairs, or arrange cleaning services — all in one place. 
              Premium service, exceptional experience.
            </p>
            <div className="flex items-center justify-center gap-4">
              <Link to="/register">
                <Button className="bg-[#D4AF37] text-black hover:bg-[#F4C430] rounded-full px-8 py-6 text-lg font-semibold gold-glow" data-testid="hero-cta-btn">
                  Book Now <ChevronRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>

          {/* Service Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 stagger-children">
            {services.map((service) => (
              <div
                key={service.id}
                className="group relative overflow-hidden rounded-2xl bg-[#121212] border border-[#262626] hover:border-[#D4AF37]/50 transition-all duration-300"
                data-testid={`service-card-${service.id}`}
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/50 to-transparent" />
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full mb-3 ${
                    service.accent === 'cyan' ? 'bg-[#00E5FF]/10 text-[#00E5FF]' : 'bg-[#D4AF37]/10 text-[#D4AF37]'
                  }`}>
                    <service.icon className="h-4 w-4" />
                    <span className="text-sm font-medium">{service.name}</span>
                  </div>
                  <p className="text-[#A3A3A3] text-sm mb-4">{service.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {service.features.map((feature, idx) => (
                      <span key={idx} className="text-xs text-[#525252] bg-[#1A1A1A] px-2 py-1 rounded">
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#0A0A0A]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-[#F5F5F5] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
              Why Choose FREEOHNS?
            </h2>
            <p className="text-[#A3A3A3] max-w-xl mx-auto">
              Experience premium service with every booking
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Clock, title: '24/7 Availability', desc: 'Book services anytime, day or night' },
              { icon: Shield, title: 'Verified Providers', desc: 'All service providers are background-checked' },
              { icon: Phone, title: 'Instant Support', desc: 'Get help whenever you need it' }
            ].map((feature, idx) => (
              <div key={idx} className="text-center p-8 rounded-2xl bg-[#121212] border border-[#262626]">
                <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-[#D4AF37]/10 flex items-center justify-center">
                  <feature.icon className="h-7 w-7 text-[#D4AF37]" />
                </div>
                <h3 className="text-xl font-semibold text-[#F5F5F5] mb-2">{feature.title}</h3>
                <p className="text-[#A3A3A3]">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t border-[#262626]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img src={LOGO_URL} alt="FREEOHNS" className="h-8 w-auto" />
              <span className="text-lg font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                FREEOHNS
              </span>
            </div>
            <p className="text-[#525252] text-sm">
              © 2024 FREEOHNS. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
