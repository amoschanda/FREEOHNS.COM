import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { toast } from 'sonner';
import { Car, Zap, Sparkles, LogOut, User, Clock, MapPin, Phone, Check, X, RefreshCw } from 'lucide-react';
import axios from 'axios';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";
const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

export default function ProviderDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('available');

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API_URL}/provider/bookings`);
      setBookings(response.data);
    } catch (error) {
      toast.error('Failed to fetch bookings');
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (bookingId) => {
    try {
      await axios.post(`${API_URL}/provider/accept/${bookingId}`);
      toast.success('Booking accepted!');
      fetchBookings();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to accept booking');
    }
  };

  const handleComplete = async (bookingId) => {
    try {
      await axios.post(`${API_URL}/provider/complete/${bookingId}`);
      toast.success('Booking marked as completed!');
      fetchBookings();
    } catch (error) {
      toast.error('Failed to complete booking');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const getServiceIcon = (type) => {
    switch (type) {
      case 'taxi': return Car;
      case 'electro_fix': return Zap;
      case 'cleaning': return Sparkles;
      default: return Car;
    }
  };

  const getServiceName = (type) => {
    switch (type) {
      case 'taxi': return 'Taxi Ride';
      case 'electro_fix': return 'Electrical Service';
      case 'cleaning': return 'Cleaning Service';
      default: return type;
    }
  };

  const getRoleIcon = () => {
    switch (user?.role) {
      case 'driver': return Car;
      case 'electrician': return Zap;
      case 'cleaner': return Sparkles;
      default: return User;
    }
  };

  const getRoleTitle = () => {
    switch (user?.role) {
      case 'driver': return 'Driver Dashboard';
      case 'electrician': return 'Electrician Dashboard';
      case 'cleaner': return 'Cleaner Dashboard';
      default: return 'Provider Dashboard';
    }
  };

  const isServiceCyan = user?.role === 'electrician';
  const accentColor = isServiceCyan ? '#00E5FF' : '#D4AF37';

  const availableBookings = bookings.filter(b => b.status === 'pending' && !b.provider_id);
  const myBookings = bookings.filter(b => b.provider_id === user?.id);
  const activeBookings = myBookings.filter(b => b.status === 'accepted');
  const completedBookings = myBookings.filter(b => b.status === 'completed');

  const RoleIcon = getRoleIcon();

  return (
    <div className="min-h-screen bg-[#050505]">
      {/* Header */}
      <header className="bg-[#0A0A0A] border-b border-[#262626] sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <img src={LOGO_URL} alt="FREEOHNS" className="h-9 w-auto" />
              <div>
                <span className="text-lg font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                  FREEOHNS
                </span>
                <p className="text-xs" style={{ color: accentColor }}>Provider Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/profile">
                <Button variant="ghost" className="text-[#A3A3A3] hover:text-white hover:bg-white/5" data-testid="profile-link">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Button
                variant="ghost"
                onClick={handleLogout}
                className="text-[#A3A3A3] hover:text-white hover:bg-white/5"
                data-testid="logout-btn"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full flex items-center justify-center" style={{ backgroundColor: `${accentColor}20` }}>
              <RoleIcon className="h-7 w-7" style={{ color: accentColor }} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                {getRoleTitle()}
              </h1>
              <p className="text-[#A3A3A3]">Welcome, {user?.full_name}</p>
            </div>
          </div>
          <Button
            onClick={fetchBookings}
            variant="outline"
            className="border-[#333] text-[#A3A3A3] hover:text-white hover:bg-[#1A1A1A]"
            data-testid="refresh-btn"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-[#121212] border border-[#262626] rounded-xl p-6">
            <p className="text-[#525252] text-sm mb-1">Available Jobs</p>
            <p className="text-3xl font-bold" style={{ color: accentColor }}>{availableBookings.length}</p>
          </div>
          <div className="bg-[#121212] border border-[#262626] rounded-xl p-6">
            <p className="text-[#525252] text-sm mb-1">Active Jobs</p>
            <p className="text-3xl font-bold text-blue-400">{activeBookings.length}</p>
          </div>
          <div className="bg-[#121212] border border-[#262626] rounded-xl p-6">
            <p className="text-[#525252] text-sm mb-1">Completed Jobs</p>
            <p className="text-3xl font-bold text-green-400">{completedBookings.length}</p>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-[#121212] border border-[#262626] mb-6">
            <TabsTrigger 
              value="available" 
              className="data-[state=active]:text-black"
              style={{ '--active-bg': accentColor }}
              data-testid="available-tab"
            >
              Available ({availableBookings.length})
            </TabsTrigger>
            <TabsTrigger 
              value="active" 
              className="data-[state=active]:bg-blue-500 data-[state=active]:text-white"
              data-testid="active-tab"
            >
              Active ({activeBookings.length})
            </TabsTrigger>
            <TabsTrigger 
              value="completed" 
              className="data-[state=active]:bg-green-500 data-[state=active]:text-white"
              data-testid="completed-tab"
            >
              Completed ({completedBookings.length})
            </TabsTrigger>
          </TabsList>

          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="w-8 h-8 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: accentColor }} />
            </div>
          ) : (
            <>
              <TabsContent value="available">
                {availableBookings.length === 0 ? (
                  <div className="text-center py-16 bg-[#121212] border border-[#262626] rounded-2xl">
                    <Clock className="h-12 w-12 text-[#525252] mx-auto mb-4" />
                    <p className="text-[#A3A3A3]">No available jobs at the moment</p>
                    <p className="text-[#525252] text-sm">Check back later for new bookings</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {availableBookings.map((booking) => (
                      <BookingCard 
                        key={booking.id} 
                        booking={booking} 
                        onAccept={handleAccept}
                        accentColor={accentColor}
                        isAvailable
                      />
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="active">
                {activeBookings.length === 0 ? (
                  <div className="text-center py-16 bg-[#121212] border border-[#262626] rounded-2xl">
                    <Clock className="h-12 w-12 text-[#525252] mx-auto mb-4" />
                    <p className="text-[#A3A3A3]">No active jobs</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {activeBookings.map((booking) => (
                      <BookingCard 
                        key={booking.id} 
                        booking={booking} 
                        onComplete={handleComplete}
                        accentColor={accentColor}
                        isActive
                      />
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="completed">
                {completedBookings.length === 0 ? (
                  <div className="text-center py-16 bg-[#121212] border border-[#262626] rounded-2xl">
                    <Check className="h-12 w-12 text-[#525252] mx-auto mb-4" />
                    <p className="text-[#A3A3A3]">No completed jobs yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {completedBookings.map((booking) => (
                      <BookingCard 
                        key={booking.id} 
                        booking={booking}
                        accentColor={accentColor}
                        isCompleted
                      />
                    ))}
                  </div>
                )}
              </TabsContent>
            </>
          )}
        </Tabs>
      </main>
    </div>
  );
}

function BookingCard({ booking, onAccept, onComplete, accentColor, isAvailable, isActive, isCompleted }) {
  const getServiceIcon = (type) => {
    switch (type) {
      case 'taxi': return Car;
      case 'electro_fix': return Zap;
      case 'cleaning': return Sparkles;
      default: return Car;
    }
  };

  const ServiceIcon = getServiceIcon(booking.service_type);

  return (
    <div className="bg-[#121212] border border-[#262626] rounded-2xl p-6 hover:border-[#D4AF37]/30 transition-colors" data-testid={`provider-booking-${booking.id}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: `${accentColor}15` }}>
            <ServiceIcon className="h-6 w-6" style={{ color: accentColor }} />
          </div>
          <div>
            <h3 className="text-[#F5F5F5] font-semibold">
              {booking.service_type === 'taxi' ? 'Taxi Ride' : booking.service_type === 'electro_fix' ? 'Electrical Service' : 'Cleaning Service'}
            </h3>
            <p className="text-[#525252] text-sm font-mono">ID: {booking.id.slice(0, 8)}...</p>
          </div>
        </div>
        {isCompleted && (
          <span className="px-3 py-1 rounded-full text-xs font-medium bg-green-400/10 text-green-400 border border-green-400/20">
            Completed
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
        <div className="flex items-center gap-2 text-[#A3A3A3]">
          <User className="h-4 w-4 text-[#525252]" />
          <span>{booking.user_name}</span>
        </div>
        <div className="flex items-center gap-2 text-[#A3A3A3]">
          <Phone className="h-4 w-4 text-[#525252]" />
          <span>{booking.user_phone}</span>
        </div>
        <div className="flex items-center gap-2 text-[#A3A3A3]">
          <Clock className="h-4 w-4 text-[#525252]" />
          <span>{booking.scheduled_date} at {booking.scheduled_time}</span>
        </div>
        <div className="flex items-center gap-2 text-[#A3A3A3]">
          <MapPin className="h-4 w-4 text-[#525252]" />
          <span className="truncate">
            {booking.service_type === 'taxi' 
              ? `${booking.pickup_address} → ${booking.dropoff_address}`
              : booking.service_address
            }
          </span>
        </div>
      </div>

      {booking.notes && (
        <p className="text-[#525252] text-sm italic mb-4 p-3 bg-[#1A1A1A] rounded-lg">
          "{booking.notes}"
        </p>
      )}

      {isAvailable && (
        <Button
          onClick={() => onAccept(booking.id)}
          className="w-full rounded-full font-semibold"
          style={{ backgroundColor: accentColor, color: '#000' }}
          data-testid={`accept-booking-${booking.id}`}
        >
          <Check className="h-4 w-4 mr-2" />
          Accept Job
        </Button>
      )}

      {isActive && (
        <Button
          onClick={() => onComplete(booking.id)}
          className="w-full bg-green-500 text-white hover:bg-green-600 rounded-full font-semibold"
          data-testid={`complete-booking-${booking.id}`}
        >
          <Check className="h-4 w-4 mr-2" />
          Mark as Completed
        </Button>
      )}
    </div>
  );
}
