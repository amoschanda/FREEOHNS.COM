import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { toast } from 'sonner';
import { ArrowLeft, Car, Zap, Sparkles, Clock, MapPin, User, Phone, X } from 'lucide-react';
import axios from 'axios';

const LOGO_URL = "https://customer-assets.emergentagent.com/job_8b7950cf-fcc0-422d-94a1-8984ffe4e7b1/artifacts/87ozudbn_da4604c0-c850-4271-8180-9962dfa9300f.png";
const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

export default function BookingHistoryPage() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const response = await axios.get(`${API_URL}/bookings`);
      setBookings(response.data);
    } catch (error) {
      toast.error('Failed to fetch bookings');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async (bookingId) => {
    try {
      await axios.delete(`${API_URL}/bookings/${bookingId}`);
      toast.success('Booking cancelled');
      fetchBookings();
    } catch (error) {
      toast.error('Failed to cancel booking');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-green-400 bg-green-400/10 border-green-400/20';
      case 'accepted': return 'text-blue-400 bg-blue-400/10 border-blue-400/20';
      case 'cancelled': return 'text-red-400 bg-red-400/10 border-red-400/20';
      default: return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
    }
  };

  const getServiceIcon = (type) => {
    switch (type) {
      case 'taxi': return Car;
      case 'electro_fix': return Zap;
      case 'cleaning': return Sparkles;
      default: return Car;
    }
  };

  const getServiceName = (type) => {
    switch (type) {
      case 'taxi': return 'Taxi Ride';
      case 'electro_fix': return 'Electrical Service';
      case 'cleaning': return 'Cleaning Service';
      default: return type;
    }
  };

  const filteredBookings = bookings.filter(booking => {
    if (activeTab === 'all') return true;
    return booking.status === activeTab;
  });

  return (
    <div className="min-h-screen bg-[#050505]">
      {/* Header */}
      <header className="bg-[#0A0A0A] border-b border-[#262626]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <img src={LOGO_URL} alt="FREEOHNS" className="h-9 w-auto" />
              <span className="text-lg font-bold text-[#F5F5F5]" style={{ fontFamily: 'Playfair Display, serif' }}>
                FREEOHNS
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to="/dashboard" className="inline-flex items-center gap-2 text-[#A3A3A3] hover:text-white mb-6 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>

        <h1 className="text-3xl font-bold text-[#F5F5F5] mb-8" style={{ fontFamily: 'Playfair Display, serif' }}>
          My Bookings
        </h1>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="bg-[#121212] border border-[#262626]">
            <TabsTrigger value="all" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              All
            </TabsTrigger>
            <TabsTrigger value="pending" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Pending
            </TabsTrigger>
            <TabsTrigger value="accepted" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Accepted
            </TabsTrigger>
            <TabsTrigger value="completed" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Completed
            </TabsTrigger>
            <TabsTrigger value="cancelled" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Cancelled
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filteredBookings.length === 0 ? (
          <div className="text-center py-20 bg-[#121212] border border-[#262626] rounded-2xl">
            <Clock className="h-16 w-16 text-[#525252] mx-auto mb-4" />
            <p className="text-[#A3A3A3] text-lg mb-2">No bookings found</p>
            <p className="text-[#525252] mb-6">
              {activeTab === 'all' ? "You haven't made any bookings yet" : `No ${activeTab} bookings`}
            </p>
            <Link to="/dashboard">
              <Button className="bg-[#D4AF37] text-black hover:bg-[#F4C430] rounded-full">
                Book a Service
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredBookings.map((booking) => {
              const ServiceIcon = getServiceIcon(booking.service_type);
              const isServiceCyan = booking.service_type === 'electro_fix';
              
              return (
                <div
                  key={booking.id}
                  className="bg-[#121212] border border-[#262626] rounded-2xl p-6 hover:border-[#D4AF37]/30 transition-colors"
                  data-testid={`booking-card-${booking.id}`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                        isServiceCyan ? 'bg-[#00E5FF]/10' : 'bg-[#D4AF37]/10'
                      }`}>
                        <ServiceIcon className={`h-6 w-6 ${isServiceCyan ? 'text-[#00E5FF]' : 'text-[#D4AF37]'}`} />
                      </div>
                      <div>
                        <h3 className="text-[#F5F5F5] font-semibold text-lg">
                          {getServiceName(booking.service_type)}
                        </h3>
                        <p className="text-[#525252] text-sm font-mono">
                          ID: {booking.id.slice(0, 8)}...
                        </p>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(booking.status)}`}>
                      {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center gap-2 text-[#A3A3A3]">
                      <Clock className="h-4 w-4 text-[#525252]" />
                      <span>{booking.scheduled_date} at {booking.scheduled_time}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[#A3A3A3]">
                      <MapPin className="h-4 w-4 text-[#525252]" />
                      <span className="truncate">
                        {booking.service_type === 'taxi' 
                          ? `${booking.pickup_address} → ${booking.dropoff_address}`
                          : booking.service_address
                        }
                      </span>
                    </div>
                  </div>

                  {booking.provider_name && (
                    <div className="flex items-center gap-2 text-[#A3A3A3] mb-4 p-3 bg-[#1A1A1A] rounded-lg">
                      <User className="h-4 w-4 text-[#D4AF37]" />
                      <span>Provider: {booking.provider_name}</span>
                    </div>
                  )}

                  {booking.notes && (
                    <p className="text-[#525252] text-sm italic mb-4">"{booking.notes}"</p>
                  )}

                  {booking.status === 'pending' && (
                    <Button
                      variant="outline"
                      onClick={() => handleCancel(booking.id)}
                      className="border-red-500/50 text-red-400 hover:bg-red-500/10 rounded-full"
                      data-testid={`cancel-booking-${booking.id}`}
                    >
                      <X className="h-4 w-4 mr-2" />
                      Cancel Booking
                    </Button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
